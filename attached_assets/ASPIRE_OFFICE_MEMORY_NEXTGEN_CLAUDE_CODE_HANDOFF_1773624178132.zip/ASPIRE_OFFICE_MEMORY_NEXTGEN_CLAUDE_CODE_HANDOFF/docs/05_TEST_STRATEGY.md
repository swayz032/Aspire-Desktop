# Test Strategy

## Unit
- validation
- scope enforcement
- reconciliation ranking
- session promotion policy
- thread-link confidence scoring

## Integration
- write event -> ledger -> thread update
- artifact store -> metadata -> signed URL
- search_memory returns reconciled facts
- promote_session writes episodic memory

## Security / negative
- cross-office retrieval attempt
- forged capability scope
- artifact access without scope
- prompt injection payload in stored document
- duplicate idempotency key replay

## Load
- 50 concurrent office briefings
- 100 concurrent memory writes
- artifact metadata burst
