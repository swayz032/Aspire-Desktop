# Implementation Plan

## Phase 1 — Foundation
- run migration
- enable `vector` and `pgcrypto`
- create S3 bucket and lifecycle rules
- implement correlation/idempotency middleware
- implement service authentication

## Phase 2 — Memory Service
- route registration
- request validation
- structured errors
- retrieval and reconciliation core
- artifact metadata service

## Phase 3 — Workers
- ingest worker
- threading worker
- distillation worker
- embedding worker
- recommendation worker

## Phase 4 — Orchestration integration
- Ava calls Memory Service only
- specialists use office-scoped memory bundles only
- Flow writes and reads office memory

## Phase 5 — Hardening
- RLS validation
- replay tests
- latency tests
- runbooks
- staged rollout by office
