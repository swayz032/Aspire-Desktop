# Rollout Plan

## Release gates
- all isolation tests pass
- retrieval p95 within target
- dead-letter queue configured
- dashboards live
- runbooks approved
- feature flag present

## Rollout
1. Internal dogfood office only
2. One low-risk pilot office
3. Five-office beta cohort
4. Wider owner-console rollout
5. Specialist integrations on by flag
