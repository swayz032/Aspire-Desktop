# Architecture

## Core principle
Office Memory is the **shared office-scoped business memory system** for one Aspire office.

## Layers
1. **Office State**: canonical structured truth in Postgres/Supabase.
2. **Office Ledger**: append-only event and receipt chain.
3. **Office Vault**: S3 object storage for artifacts, transcripts, recordings, exports.
4. **Office Threads**: continuity layer joining calls, email, contracts, invoices, approvals, and outcomes.
5. **Office Index**: pgvector-based semantic retrieval over summaries and selected long-form content.
6. **Memory Service**: the only supported API for reads and writes.

## Hard rules
- Facts come from structured state.
- Context comes from retrieval.
- Every memory operation carries `suite_id`, `office_id`, `correlation_id`, and `capability_scope`.
- Every consequential write yields a ledger event and, where applicable, a receipt.
- Memory must remain useful even if vector retrieval is degraded.

## Query pipeline
1. Validate office boundary and capability scope.
2. Detect query mode: fact lookup, thread lookup, semantic search, or replay.
3. Retrieve candidate context.
4. Reconcile against structured truth and receipt lineage.
5. Redact disallowed fields.
6. Return an action-safe context bundle.

## Write pipeline
1. Validate idempotency and scope.
2. Write structured state if needed.
3. Append ledger event.
4. Persist artifact metadata and/or object pointer.
5. Update thread summary.
6. Generate retrieval chunks asynchronously.
