# Runbooks

## Incident: cross-office retrieval suspicion
1. Disable Office Memory feature flag for affected offices.
2. Block retrieval endpoint if necessary.
3. Pull audit logs by `correlation_id`, `suite_id`, `office_id`.
4. Verify RLS policy evaluation and route guard logs.
5. Rotate service tokens if misuse suspected.
6. Prepare receipt bundle and incident artifact set.

## Incident: embedding backlog growth
1. Inspect worker queue depth.
2. Verify provider health and rate limits.
3. Temporarily degrade to structured-only retrieval.
4. Reprocess dead-letter queue after provider recovers.

## Incident: signed URL misuse
1. Revoke object access path via server proxy mode.
2. Reduce TTL.
3. Inspect audit logs for repeated downloads.
4. Rotate IAM credentials if necessary.
