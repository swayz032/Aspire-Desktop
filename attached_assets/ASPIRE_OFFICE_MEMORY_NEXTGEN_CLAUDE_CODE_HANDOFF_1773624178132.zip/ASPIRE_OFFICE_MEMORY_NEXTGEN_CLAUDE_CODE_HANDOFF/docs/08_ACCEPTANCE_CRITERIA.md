# Acceptance Criteria

Office Memory is done only when all of the following are true:

1. Every important action can produce structured state, ledger event, and receipt lineage.
2. Every artifact is stored with metadata and safe retrieval rules.
3. Every query is office-scoped, capability-scoped, and audited.
4. Retrieval results are reconciled against authoritative state before action use.
5. Ava can answer:
   - what happened
   - what changed
   - what matters
   - what next
6. Specialists receive scoped memory bundles, not raw store access.
7. Flow reads and updates Office Memory.
8. Cross-office retrieval tests pass.
9. Degraded mode works without vector retrieval.
10. p95 latency is acceptable for daily use.
