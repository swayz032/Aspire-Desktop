# Security and Threat Model

## Trust boundaries
- public client
- Aspire backend
- Memory Service
- Postgres
- S3
- embedding provider

## Threats
1. Cross-office data leakage
2. Capability escalation by a specialist
3. Replay or duplicate memory writes
4. Unauthorized artifact access
5. Retrieval returning stale or contradictory context
6. Sensitive transcript over-indexing
7. Prompt injection inside stored documents

## Required controls
- deny-by-default scope enforcement
- RLS plus app-level checks
- short-lived signed URLs only
- append-only ledger
- idempotency key on write APIs
- retrieval reconciliation before action
- metadata-based redaction
- audit logging of sensitive reads
- prompt-injection scrubbing in retrieval pipeline
