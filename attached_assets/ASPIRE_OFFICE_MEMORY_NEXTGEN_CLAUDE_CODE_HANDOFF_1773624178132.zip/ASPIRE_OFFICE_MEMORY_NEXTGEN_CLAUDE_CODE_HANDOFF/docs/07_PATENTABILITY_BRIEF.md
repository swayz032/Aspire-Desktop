# Patentability Brief (Planning Only)

## Goal
Shape Office Memory as a specific technical invention, not a broad business concept.

## Candidate invention thesis
A tenant-isolated virtual-office memory fabric that reconciles authoritative business state, receipt lineage, and semantically retrieved context before action context is released to an orchestrator or specialist.

## Claim-family themes
1. Hybrid memory with authoritative-state reconciliation
2. Receipt-linked office-thread causality
3. Capability-scoped retrieval bundles
4. Replayable office-state materialization
5. Orchestrator-mediated action context issuance

## Keep as trade secret
- ranking heuristics
- reconciliation scoring
- prompt-injection scrubbing
- thread-link confidence thresholds
