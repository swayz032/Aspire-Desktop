# Aspire Office Memory — Next-Generation Claude Code Handoff

## Objective
Implement **Office Memory** as production infrastructure for Aspire. This package is **backend, data, orchestration, security, and testing only**. UI/UX design is intentionally excluded.

## What this upgrade adds
Compared with the prior handoff, this package adds:
- production-grade folder structure
- concrete SQL migration
- typed TypeScript interfaces
- Memory Service route stubs
- retrieval/reconciliation service stubs
- background worker stubs
- OpenAPI draft
- env template
- test skeletons
- rollout and runbook guidance

## Non-negotiables
- **One office = one memory boundary**
- **Structured state is truth**
- **Receipts and ledger are append-only**
- **RAG is support, not truth**
- **All memory access is server-governed**
- **No direct raw DB / vector / S3 access from agents**
- **Draft -> Authority -> Receipt remains the only consequential execution path**
- **Deny by default**
- **Capability-scoped retrieval only**
- **No cross-tenant leakage**

## Architecture
```text
Office Memory
├── Office State       (authoritative structured truth)
├── Office Ledger      (append-only events and receipts)
├── Office Vault       (S3 artifacts and transcripts)
├── Office Threads     (client/job/deal/invoice/contract continuity)
├── Office Index       (pgvector retrieval layer)
└── Memory Service     (single read/write gateway for Ava and specialists)
```

## Build order
1. Run the SQL migration
2. Wire environment and secrets
3. Implement Memory Service route handlers
4. Implement retrieval + reconciliation
5. Implement workers
6. Wire Ava and specialists to Memory Service only
7. Run tests
8. Enable via feature flag by office

## Definition of done
Use `docs/08_ACCEPTANCE_CRITERIA.md`. If a criterion fails, Office Memory is not done.
