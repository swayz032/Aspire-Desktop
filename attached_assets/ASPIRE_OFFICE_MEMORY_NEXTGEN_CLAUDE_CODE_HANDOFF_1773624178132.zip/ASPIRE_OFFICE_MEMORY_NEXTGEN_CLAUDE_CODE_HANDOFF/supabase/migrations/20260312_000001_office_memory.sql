-- Aspire Office Memory foundation
create extension if not exists pgcrypto;
create extension if not exists vector;

create table if not exists office_threads (
  id uuid primary key default gen_random_uuid(),
  suite_id uuid not null,
  office_id uuid not null,
  thread_type text not null check (thread_type in ('client','job','deal','invoice','contract','task','internal')),
  title text not null,
  primary_entity_type text not null,
  primary_entity_id uuid not null,
  status text not null default 'open',
  summary text,
  last_activity_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_office_threads_office on office_threads(suite_id, office_id);
create index if not exists idx_office_threads_entity on office_threads(primary_entity_type, primary_entity_id);

create table if not exists receipts (
  id uuid primary key default gen_random_uuid(),
  suite_id uuid not null,
  office_id uuid not null,
  thread_id uuid references office_threads(id) on delete set null,
  receipt_type text not null,
  status text not null check (status in ('success','pending','blocked','failed')),
  risk_tier text not null check (risk_tier in ('green','yellow','red')),
  source_surface text not null,
  summary text not null,
  decision_text text,
  approval_state text not null default 'not_required',
  execution_state text not null default 'recorded',
  entity_type text,
  entity_id uuid,
  created_by_type text not null,
  created_by_id uuid,
  created_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb
);

create index if not exists idx_receipts_office on receipts(suite_id, office_id, created_at desc);
create index if not exists idx_receipts_thread on receipts(thread_id, created_at desc);

create table if not exists office_ledger_events (
  id uuid primary key default gen_random_uuid(),
  suite_id uuid not null,
  office_id uuid not null,
  thread_id uuid references office_threads(id) on delete set null,
  receipt_id uuid references receipts(id) on delete set null,
  event_type text not null,
  event_time timestamptz not null default now(),
  actor_type text not null,
  actor_id uuid,
  source_surface text not null,
  entity_type text,
  entity_id uuid,
  risk_tier text not null check (risk_tier in ('green','yellow','red')),
  status text not null,
  summary text not null,
  next_step text,
  correlation_id uuid not null,
  idempotency_key text,
  artifact_refs uuid[] not null default '{}',
  metadata jsonb not null default '{}'::jsonb
);

create unique index if not exists uq_office_ledger_idempotency
  on office_ledger_events(suite_id, office_id, idempotency_key)
  where idempotency_key is not null;

create index if not exists idx_ledger_office on office_ledger_events(suite_id, office_id, event_time desc);

create table if not exists artifacts (
  id uuid primary key default gen_random_uuid(),
  suite_id uuid not null,
  office_id uuid not null,
  thread_id uuid references office_threads(id) on delete set null,
  entity_type text,
  entity_id uuid,
  artifact_type text not null,
  storage_key text not null unique,
  mime_type text not null,
  size_bytes bigint not null check (size_bytes >= 0),
  sha256 text not null,
  classification text not null default 'internal',
  retention_policy text not null default 'standard',
  source_surface text not null,
  created_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb
);

create index if not exists idx_artifacts_office on artifacts(suite_id, office_id, created_at desc);

create table if not exists office_memory_chunks (
  id uuid primary key default gen_random_uuid(),
  suite_id uuid not null,
  office_id uuid not null,
  thread_id uuid references office_threads(id) on delete cascade,
  entity_type text,
  entity_id uuid,
  source_type text not null,
  source_ref_id uuid,
  summary_text text,
  chunk_text text not null,
  chunk_hash text not null,
  embedding vector(3072),
  security_label text not null default 'internal',
  is_redacted boolean not null default false,
  created_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb
);

create index if not exists idx_chunks_office on office_memory_chunks(suite_id, office_id, created_at desc);
create unique index if not exists uq_chunks_hash on office_memory_chunks(suite_id, office_id, chunk_hash);
create index if not exists idx_chunks_embedding on office_memory_chunks using ivfflat (embedding vector_cosine_ops) with (lists = 100);

create table if not exists office_session_promotions (
  id uuid primary key default gen_random_uuid(),
  suite_id uuid not null,
  office_id uuid not null,
  session_type text not null check (session_type in ('chat','voice','video','conference')),
  session_ref text not null,
  summary text not null,
  promoted_to_thread_id uuid references office_threads(id) on delete set null,
  promoted_to_office_memory boolean not null default false,
  promoted_by_type text not null,
  promoted_by_id uuid,
  confidence numeric(5,4) not null check (confidence >= 0 and confidence <= 1),
  created_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb
);

alter table office_threads enable row level security;
alter table receipts enable row level security;
alter table office_ledger_events enable row level security;
alter table artifacts enable row level security;
alter table office_memory_chunks enable row level security;
alter table office_session_promotions enable row level security;

-- Template RLS. Adapt to Aspire auth claims model before production.
create policy office_threads_isolation on office_threads
  using (
    suite_id::text = coalesce((current_setting('request.jwt.claims', true)::jsonb ->> 'suite_id'), suite_id::text)
    and office_id::text = coalesce((current_setting('request.jwt.claims', true)::jsonb ->> 'office_id'), office_id::text)
  );

create policy receipts_isolation on receipts
  using (
    suite_id::text = coalesce((current_setting('request.jwt.claims', true)::jsonb ->> 'suite_id'), suite_id::text)
    and office_id::text = coalesce((current_setting('request.jwt.claims', true)::jsonb ->> 'office_id'), office_id::text)
  );

create policy office_ledger_events_isolation on office_ledger_events
  using (
    suite_id::text = coalesce((current_setting('request.jwt.claims', true)::jsonb ->> 'suite_id'), suite_id::text)
    and office_id::text = coalesce((current_setting('request.jwt.claims', true)::jsonb ->> 'office_id'), office_id::text)
  );

create policy artifacts_isolation on artifacts
  using (
    suite_id::text = coalesce((current_setting('request.jwt.claims', true)::jsonb ->> 'suite_id'), suite_id::text)
    and office_id::text = coalesce((current_setting('request.jwt.claims', true)::jsonb ->> 'office_id'), office_id::text)
  );

create policy office_memory_chunks_isolation on office_memory_chunks
  using (
    suite_id::text = coalesce((current_setting('request.jwt.claims', true)::jsonb ->> 'suite_id'), suite_id::text)
    and office_id::text = coalesce((current_setting('request.jwt.claims', true)::jsonb ->> 'office_id'), office_id::text)
  );

create policy office_session_promotions_isolation on office_session_promotions
  using (
    suite_id::text = coalesce((current_setting('request.jwt.claims', true)::jsonb ->> 'suite_id'), suite_id::text)
    and office_id::text = coalesce((current_setting('request.jwt.claims', true)::jsonb ->> 'office_id'), office_id::text)
  );
