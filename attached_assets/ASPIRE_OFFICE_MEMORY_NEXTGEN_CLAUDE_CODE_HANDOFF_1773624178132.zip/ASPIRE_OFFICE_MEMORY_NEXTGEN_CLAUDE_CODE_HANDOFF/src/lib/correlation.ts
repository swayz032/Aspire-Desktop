import crypto from 'node:crypto';

export function getOrCreateCorrelationId(value?: string): string {
  return value && value.length > 0 ? value : crypto.randomUUID();
}
