export class AppError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly httpStatus: number,
    public readonly details?: Record<string, unknown>,
  ) {
    super(message);
    this.name = 'AppError';
  }
}

export const forbidden = (message = 'Forbidden', details?: Record<string, unknown>) =>
  new AppError('FORBIDDEN', message, 403, details);

export const badRequest = (message = 'Bad Request', details?: Record<string, unknown>) =>
  new AppError('BAD_REQUEST', message, 400, details);

export const conflict = (message = 'Conflict', details?: Record<string, unknown>) =>
  new AppError('CONFLICT', message, 409, details);

export const internal = (message = 'Internal Server Error', details?: Record<string, unknown>) =>
  new AppError('INTERNAL', message, 500, details);
