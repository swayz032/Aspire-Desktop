import { conflict } from './errors.js';

export async function ensureIdempotentWrite(
  idempotencyKey: string,
  scopeKey: string,
): Promise<void> {
  // TODO: implement against Redis/Postgres lock table.
  // Must reject duplicate writes for same office boundary and key.
  if (!idempotencyKey || !scopeKey) {
    throw conflict('Missing idempotency inputs');
  }
}
