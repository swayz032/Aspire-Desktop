export type UUID = string;

export type RiskTier = 'green' | 'yellow' | 'red';
export type ReceiptStatus = 'success' | 'pending' | 'blocked' | 'failed';
export type ThreadType = 'client' | 'job' | 'deal' | 'invoice' | 'contract' | 'task' | 'internal';
export type SessionType = 'chat' | 'voice' | 'video' | 'conference';

export interface OfficeScope {
  suiteId: UUID;
  officeId: UUID;
  correlationId: UUID;
}

export interface CapabilityScope {
  actorType: 'owner' | 'team_member' | 'ava' | 'specialist' | 'system';
  actorId?: UUID;
  capabilities: string[];
  allowSensitiveRead: boolean;
  riskCeiling: RiskTier;
}

export interface SearchMemoryRequest {
  scope: OfficeScope;
  capabilityScope: CapabilityScope;
  query: string;
  queryMode?: 'fact' | 'thread' | 'semantic' | 'replay' | 'auto';
  topK?: number;
  filters?: {
    threadId?: UUID;
    entityType?: string;
    entityId?: UUID;
    sourceTypes?: string[];
    startTime?: string;
    endTime?: string;
  };
}

export interface MemoryFact {
  label: string;
  value: string | number | boolean | null;
  source: 'structured_state' | 'receipt' | 'derived';
}

export interface MemoryCitation {
  sourceType: string;
  sourceRefId?: UUID;
  threadId?: UUID;
  artifactId?: UUID;
  summary: string;
}

export interface SearchMemoryResponse {
  facts: MemoryFact[];
  citations: MemoryCitation[];
  answerContext: string;
  relatedThreadIds: UUID[];
}

export interface WriteMemoryEventRequest {
  scope: OfficeScope;
  capabilityScope: CapabilityScope;
  idempotencyKey: string;
  eventType: string;
  riskTier: RiskTier;
  status: string;
  sourceSurface: string;
  entityType?: string;
  entityId?: UUID;
  threadId?: UUID;
  summary: string;
  nextStep?: string;
  metadata?: Record<string, unknown>;
}

export interface PromoteSessionRequest {
  scope: OfficeScope;
  capabilityScope: CapabilityScope;
  sessionType: SessionType;
  sessionRef: string;
  summary: string;
  memoryCandidates: string[];
  threadHints?: Array<{ threadType: ThreadType; primaryEntityType: string; primaryEntityId: UUID }>;
  officePreferenceUpdates?: string[];
  confidence: number;
}
