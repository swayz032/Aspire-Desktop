export async function embedTexts(_texts: string[]): Promise<number[][]> {
  // TODO:
  // - call embedding provider
  // - handle retry/backoff
  // - emit metrics
  return [];
}
