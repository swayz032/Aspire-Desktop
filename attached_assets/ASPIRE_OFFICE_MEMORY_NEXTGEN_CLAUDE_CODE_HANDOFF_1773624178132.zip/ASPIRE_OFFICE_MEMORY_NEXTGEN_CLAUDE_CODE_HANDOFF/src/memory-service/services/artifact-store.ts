export interface PresignedUploadResult {
  artifactId: string;
  storageKey: string;
  uploadUrl: string;
  expiresInSeconds: number;
}

export async function createArtifactUpload(): Promise<PresignedUploadResult> {
  // TODO: persist artifact metadata row first, then create presigned URL.
  return {
    artifactId: 'TODO',
    storageKey: 'TODO',
    uploadUrl: 'TODO',
    expiresInSeconds: 300,
  };
}
