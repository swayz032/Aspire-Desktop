export interface ThreadHint {
  threadType: string;
  primaryEntityType: string;
  primaryEntityId: string;
}

export async function resolveThreadForEvent(_summary: string, _hints: ThreadHint[]): Promise<string | null> {
  // TODO:
  // - match by primary entity
  // - match by sender/caller/contact
  // - use confidence threshold for auto-link
  // - return null when confidence is low
  return null;
}
