import type { CapabilityScope } from '../../types/office-memory.js';
import { forbidden } from '../../lib/errors.js';

export function requireCapability(scope: CapabilityScope, capability: string): void {
  if (!scope.capabilities.includes(capability)) {
    throw forbidden(`Missing capability: ${capability}`);
  }
}
