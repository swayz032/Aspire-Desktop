import type { MemoryFact } from '../../types/office-memory.js';

export interface CandidateContext {
  facts: MemoryFact[];
  contradictions: string[];
  citations: Array<{ source: string; sourceRefId?: string }>;
}

export async function reconcileCandidateContext(candidate: CandidateContext): Promise<CandidateContext> {
  // TODO:
  // 1. fetch authoritative rows for any referenced entities
  // 2. prefer structured facts over retrieval-only facts
  // 3. mark contradictions explicitly
  // 4. downgrade stale or unapproved context
  return candidate;
}
