export async function auditSensitiveRead(params: {
  suiteId: string;
  officeId: string;
  actorType: string;
  actorId?: string;
  resourceType: string;
  resourceId?: string;
  correlationId: string;
}): Promise<void> {
  // TODO: write audit log event to security log sink.
  void params;
}
