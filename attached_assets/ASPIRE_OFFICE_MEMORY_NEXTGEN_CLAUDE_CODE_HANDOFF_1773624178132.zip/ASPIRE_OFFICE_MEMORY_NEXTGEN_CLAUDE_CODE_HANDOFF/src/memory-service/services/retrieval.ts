import type { SearchMemoryRequest, SearchMemoryResponse } from '../../types/office-memory.js';

export async function searchMemory(_request: SearchMemoryRequest): Promise<SearchMemoryResponse> {
  // TODO:
  // - detect query mode
  // - gather structured facts first when appropriate
  // - run vector search for semantic context
  // - fetch recent receipts and thread summary
  // - reconcile before returning
  return {
    facts: [],
    citations: [],
    answerContext: 'TODO: implement searchMemory',
    relatedThreadIds: [],
  };
}
