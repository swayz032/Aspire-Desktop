import type { PromoteSessionRequest } from '../../types/office-memory.js';

export async function promoteSession(_request: PromoteSessionRequest): Promise<void> {
  // TODO:
  // - classify memory candidates
  // - promote to office-wide memory vs thread memory
  // - write session promotion record
  // - create ledger event when durable operational memory changes
}
