import type { FastifyInstance } from 'fastify';
import { z } from 'zod';

const schema = z.object({
  scope: z.object({ suiteId: z.string(), officeId: z.string(), correlationId: z.string() }),
  capabilityScope: z.object({
    actorType: z.string(),
    actorId: z.string().optional(),
    capabilities: z.array(z.string()),
    allowSensitiveRead: z.boolean(),
    riskCeiling: z.enum(['green','yellow','red']),
  }),
  query: z.string().min(1),
  queryMode: z.enum(['fact','thread','semantic','replay','auto']).optional(),
  topK: z.number().int().positive().max(50).optional(),
});

export function registerSearchMemoryRoute(app: FastifyInstance) {
  app.post('/v1/search-memory', async (request) => {
    const body = schema.parse(request.body);
    // TODO: implement production handler.
    return {
      ok: true,
      route: '/v1/search-memory',
      received: body,
    };
  });
}
