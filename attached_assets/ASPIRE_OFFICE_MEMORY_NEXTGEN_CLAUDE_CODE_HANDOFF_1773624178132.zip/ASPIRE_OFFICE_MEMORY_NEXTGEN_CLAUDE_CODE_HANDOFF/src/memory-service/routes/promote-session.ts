import type { FastifyInstance } from 'fastify';
import { z } from 'zod';

const schema = z.object({
  scope: z.object({ suiteId: z.string(), officeId: z.string(), correlationId: z.string() }),
  capabilityScope: z.object({
    actorType: z.string(),
    actorId: z.string().optional(),
    capabilities: z.array(z.string()),
    allowSensitiveRead: z.boolean(),
    riskCeiling: z.enum(['green','yellow','red']),
  }),
  sessionType: z.enum(['chat','voice','video','conference']),
  sessionRef: z.string().min(1),
  summary: z.string().min(1),
  memoryCandidates: z.array(z.string()),
  confidence: z.number().min(0).max(1),
});

export function registerPromoteSessionRoute(app: FastifyInstance) {
  app.post('/v1/promote-session', async (request) => {
    const body = schema.parse(request.body);
    // TODO: implement production handler.
    return {
      ok: true,
      route: '/v1/promote-session',
      received: body,
    };
  });
}
