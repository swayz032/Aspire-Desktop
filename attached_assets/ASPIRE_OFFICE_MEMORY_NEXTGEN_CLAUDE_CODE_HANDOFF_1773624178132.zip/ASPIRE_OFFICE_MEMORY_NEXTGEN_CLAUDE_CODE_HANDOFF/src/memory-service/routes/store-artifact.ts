import type { FastifyInstance } from 'fastify';
import { z } from 'zod';

const schema = z.object({
  scope: z.object({ suiteId: z.string(), officeId: z.string(), correlationId: z.string() }),
  capabilityScope: z.object({
    actorType: z.string(),
    capabilities: z.array(z.string()),
    allowSensitiveRead: z.boolean(),
    riskCeiling: z.enum(['green','yellow','red']),
  }),
  artifactType: z.string().min(1),
  mimeType: z.string().min(1),
  sizeBytes: z.number().int().nonnegative(),
  sha256: z.string().min(1),
  threadId: z.string().uuid().optional(),
  entityType: z.string().optional(),
  entityId: z.string().uuid().optional(),
});

export function registerStoreArtifactRoute(app: FastifyInstance) {
  app.post('/v1/store-artifact', async (request) => {
    const body = schema.parse(request.body);
    // TODO: implement production handler.
    return {
      ok: true,
      route: '/v1/store-artifact',
      received: body,
    };
  });
}
