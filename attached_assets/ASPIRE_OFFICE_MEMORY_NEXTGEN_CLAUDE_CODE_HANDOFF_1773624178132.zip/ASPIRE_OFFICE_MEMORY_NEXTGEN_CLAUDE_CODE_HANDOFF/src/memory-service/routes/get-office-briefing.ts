import type { FastifyInstance } from 'fastify';
import { z } from 'zod';

const schema = z.object({
  scope: z.object({ suiteId: z.string(), officeId: z.string(), correlationId: z.string() }),
  capabilityScope: z.object({
    actorType: z.string(),
    capabilities: z.array(z.string()),
    allowSensitiveRead: z.boolean(),
    riskCeiling: z.enum(['green','yellow','red']),
  }),
  forDate: z.string().optional(),
});

export function registerGetOfficeBriefingRoute(app: FastifyInstance) {
  app.post('/v1/get-office-briefing', async (request) => {
    const body = schema.parse(request.body);
    // TODO: implement production handler.
    return {
      ok: true,
      route: '/v1/get-office-briefing',
      received: body,
    };
  });
}
