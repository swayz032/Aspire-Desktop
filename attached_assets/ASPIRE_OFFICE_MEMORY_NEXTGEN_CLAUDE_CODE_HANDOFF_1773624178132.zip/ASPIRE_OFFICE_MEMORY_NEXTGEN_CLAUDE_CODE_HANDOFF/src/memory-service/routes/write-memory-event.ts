import type { FastifyInstance } from 'fastify';
import { z } from 'zod';

const schema = z.object({
  scope: z.object({ suiteId: z.string(), officeId: z.string(), correlationId: z.string() }),
  capabilityScope: z.object({
    actorType: z.string(),
    actorId: z.string().optional(),
    capabilities: z.array(z.string()),
    allowSensitiveRead: z.boolean(),
    riskCeiling: z.enum(['green','yellow','red']),
  }),
  idempotencyKey: z.string().min(1),
  eventType: z.string().min(1),
  riskTier: z.enum(['green','yellow','red']),
  status: z.string().min(1),
  sourceSurface: z.string().min(1),
  summary: z.string().min(1),
  entityType: z.string().optional(),
  entityId: z.string().uuid().optional(),
  threadId: z.string().uuid().optional(),
});

export function registerWriteMemoryEventRoute(app: FastifyInstance) {
  app.post('/v1/write-memory-event', async (request) => {
    const body = schema.parse(request.body);
    // TODO: implement production handler.
    return {
      ok: true,
      route: '/v1/write-memory-event',
      received: body,
    };
  });
}
