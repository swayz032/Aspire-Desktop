import Fastify from 'fastify';
import { env } from '../lib/env.js';
import { registerSearchMemoryRoute } from './routes/search-memory.js';
import { registerGetThreadRoute } from './routes/get-thread.js';
import { registerGetEntityMemoryRoute } from './routes/get-entity-memory.js';
import { registerWriteMemoryEventRoute } from './routes/write-memory-event.js';
import { registerStoreArtifactRoute } from './routes/store-artifact.js';
import { registerPromoteSessionRoute } from './routes/promote-session.js';
import { registerGetOfficeBriefingRoute } from './routes/get-office-briefing.js';

export async function buildServer() {
  const app = Fastify({ logger: { level: env.LOG_LEVEL } });

  app.addHook('onRequest', async (request) => {
    const token = request.headers['x-internal-service-token'];
    if (token !== env.INTERNAL_SERVICE_TOKEN) {
      throw app.httpErrors.unauthorized();
    }
  });

  registerSearchMemoryRoute(app);
  registerGetThreadRoute(app);
  registerGetEntityMemoryRoute(app);
  registerWriteMemoryEventRoute(app);
  registerStoreArtifactRoute(app);
  registerPromoteSessionRoute(app);
  registerGetOfficeBriefingRoute(app);

  return app;
}

if (process.env.NODE_ENV !== 'test') {
  buildServer().then((app) => {
    app.listen({ port: env.PORT, host: '0.0.0.0' });
  });
}
