export async function runEmbeddingWorker(): Promise<void> {
  // TODO: implement chunk embedding and index refresh.
}
