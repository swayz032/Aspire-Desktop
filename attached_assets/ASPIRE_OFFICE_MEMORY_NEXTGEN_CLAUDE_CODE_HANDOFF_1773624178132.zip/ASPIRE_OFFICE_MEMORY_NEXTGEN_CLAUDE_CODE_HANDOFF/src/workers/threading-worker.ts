export async function runThreadingWorker(): Promise<void> {
  // TODO: implement thread linking and confidence scoring.
}
