import { describe, expect, it } from 'vitest';

describe('tenant isolation', () => {
  it('blocks cross-office retrieval', async () => {
    expect(true).toBe(true); // TODO
  });

  it('blocks artifact access outside office scope', async () => {
    expect(true).toBe(true); // TODO
  });
});
