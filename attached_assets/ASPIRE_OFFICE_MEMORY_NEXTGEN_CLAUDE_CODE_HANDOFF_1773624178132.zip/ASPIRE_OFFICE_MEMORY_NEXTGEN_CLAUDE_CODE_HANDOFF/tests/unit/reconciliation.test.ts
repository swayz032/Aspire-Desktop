import { describe, expect, it } from 'vitest';

describe('reconciliation', () => {
  it('prefers structured facts over retrieval-only facts', async () => {
    expect(true).toBe(true); // TODO
  });

  it('surfaces contradictions explicitly', async () => {
    expect(true).toBe(true); // TODO
  });
});
