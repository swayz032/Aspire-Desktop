# Finance Hub Startup Modes

## 1. Why modes exist
Finance Hub should not open the same way for every user.

The system must adapt based on:
- onboarding profile
- provider state
- memory state
- data cleanliness
- first-run vs ongoing use

## 2. Control split
- **Ava** determines startup mode
- **Finn** runs the finance experience inside that mode

## 3. Mode A — Setup Mode
### Use when
- no meaningful provider data is connected
- provider coverage is insufficient
- Finance Story Engine cannot produce a useful story yet

### Goal
- connect sources
- confirm business accounts
- create first money story

### First-run messaging
- what data is connected
- what is missing
- what will happen next
- why account confirmation matters

## 4. Mode B — Catch-Up Mode
### Use when
- there are 6–12+ months of activity
- classification and mapping backlog is high
- the owner needs cleanup before daily operations

### Goal
- turn a messy year into a review plan
- identify likely business expense candidates
- separate owner activity and transfers
- reduce tax-prep anxiety

### First-run messaging
- “I found a year of activity.”
- “We should start with the highest-value cleanup items.”
- “You do not need to fix everything at once.”

## 5. Mode C — Operating Mode
### Use when
- major providers are connected
- mapping is in acceptable shape
- the owner is in ongoing weekly/daily operations

### Goal
- show today’s money story
- surface pressure and review items
- move work forward

### First-run messaging
- cash truth
- what changed
- what needs review
- what to do next

## 6. Mode selection signals
- provider coverage
- mapping coverage
- unresolved task count
- historical data volume
- confidence level
- previous finance memory state
- onboarding pain point

## 7. UI rule
Do not drop users into generic tabs first.

On entry, show:
- the mode
- what the system sees
- what is missing
- the first best next step
