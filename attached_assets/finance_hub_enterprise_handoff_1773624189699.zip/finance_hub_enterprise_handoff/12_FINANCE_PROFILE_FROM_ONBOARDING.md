# Finance Profile from Onboarding

## 1. Why onboarding matters
Aspire’s onboarding intake already captures many of the fields Finance Hub needs to create a useful first-run finance experience.

Finance Hub should not treat the user like a blank slate.

## 2. Fields Finance Hub should consume
- businessName
- firstName / lastName -> ownerName
- ownerTitle
- industry
- industrySpecialty
- teamSize
- entityType
- yearsInBusiness
- business address
- timezone
- currency
- incomeRange
- painPoint
- personalization consent

## 3. Fields Finance Hub should usually ignore
- gender
- dateOfBirth

These may matter elsewhere, but are not core to the finance experience.

## 4. Finance Intake Profile shape
```ts
type FinanceIntakeProfile = {
  suiteId: string;
  officeId: string;
  businessName: string;
  ownerName: string;
  ownerTitle: string | null;
  industry: string;
  industrySpecialty: string | null;
  teamSize: string | null;
  entityType: string | null;
  yearsInBusiness: string | null;
  businessCity: string | null;
  businessState: string | null;
  businessCountry: 'US';
  timezone: string | null;
  currency: 'USD';
  incomeRange: string | null;
  primaryPainPoint: string | null;
  personalizationConsent: boolean;
};
```

## 5. Personalization rules
### Construction & Trades small-team owner
Bias first-run Finance Hub toward:
- fuel
- lodging
- meals
- materials
- subcontractors
- invoice lag
- tax-review readiness
- transfer confusion
- reserve pressure

### Pain-point driven adaptation
- tax pain -> start with Write-Off Radar and Catch-Up Mode
- cash pain -> start with Cash Truth and overdue invoices
- bookkeeping confusion -> start with cleanup / classification workbench

## 6. Architecture rule
Do not let Finance Hub read raw onboarding form data ad hoc.

Create one derived read model:
- Finance Intake Profile

Use that in:
- startup mode selection
- Finance Story Engine
- Finn prompts
- page defaults
