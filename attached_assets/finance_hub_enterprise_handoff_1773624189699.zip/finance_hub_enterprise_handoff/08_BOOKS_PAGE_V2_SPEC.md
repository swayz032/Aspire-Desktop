# Books Page v2 Spec

## 1. Purpose
Books becomes the accounting workbench.

It should stop feeling like QuickBooks mirrored inside Aspire.

## 2. Why rebuild is required
Current books structure is too accounting-shaped:
- Overview
- Reports
- Money Shelves
- Money Moves
- Money Trail

That is useful, but not strong enough for the new finance engine posture.

## 3. New section model
### A. Book Truth
- booked revenue
- booked expenses
- booked profit
- A/R
- A/P
- unreconciled amount
- classification backlog

### B. Classification Workbench
Main working lane for:
- uncategorized transactions
- merchant clusters
- owner draw suggestions
- transfer suggestions
- apply-to-similar flows

### C. Reconciliation Grid
Rows should support:
- matched
- suggested
- unmatched
- excluded
- duplicate candidate
- transfer pair candidate

### D. Tax-Prep Lane
- likely deduction candidates
- evidence gaps
- mixed-use risk
- quarter-to-date readiness

### E. Accounting Memory
- why a classification happened
- who approved it
- what evidence supported it
- what similar decisions exist

## 4. UX rules
- default to owner-safe language
- allow accountant depth without making it the first-run surface
- classify once, apply to similar where confidence is strong
- show why recommendations exist

## 5. Critical owner actions
- mark as transfer
- mark as owner draw
- mark as business expense
- attach to customer/job/vendor
- review later
- confirm business-use share

## 6. Relationship to Finance Story Engine
Books is not the narrator.
Books is the workbench where ambiguity gets resolved.
