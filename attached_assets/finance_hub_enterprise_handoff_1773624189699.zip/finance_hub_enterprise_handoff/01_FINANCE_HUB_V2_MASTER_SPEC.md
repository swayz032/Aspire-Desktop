# Finance Hub v2 Master Spec

## 1. Executive summary
Finance Hub v2 must stop behaving like three connected tools and become:

> one reconciled money cockpit for SMB owners, powered by a Finance Story Engine, the finance lens of Office Memory, and Finn as the finance specialist skill pack.

The product exists for owners who:
- make real money
- have real expenses
- have messy records
- do not have strong financial literacy
- feel tax pressure
- need financial translation, not more reports

## 2. Product thesis
The current market often forces small business owners into this pattern:
- bank app for balances
- QuickBooks for reports
- Stripe for invoices
- accountant for interpretation
- tax-time panic
- owner guessing in between

Finance Hub v2 replaces that with:
- one cockpit
- one money story
- one memory spine
- one action queue
- one explanation layer
- one owner journey: connect -> confirm -> understand -> act

## 3. Core principles
### 3.1 One cockpit, not moving parts
Do not render provider-first surfaces as the primary experience.

### 3.2 Owner-first, accountant-safe
Default to plain English. Put accountant detail behind deliberate access.

### 3.3 Story before reports
Default questions:
1. What money is real?
2. What changed?
3. What needs review?
4. What should I do next?

### 3.4 One memory spine
Office Memory is the only memory system. Finance Memory is the finance-scoped view.

### 3.5 Ava orchestrates, Finn specializes
Ava chooses entry mode and routing. Finn runs finance analysis and finance workflows.

### 3.6 No fake certainty
Never silently merge unmapped provider data into trusted totals.

### 3.7 USD only
All canonical calculations are USD-only in v1.

## 4. Product promise
> Finance Hub turns a messy year of money into a clean financial story, a review queue, and a tax-prep-ready starting point — without requiring the owner to think like an accountant.

## 5. What changes in v2
### Keep mostly intact
- Cash page shell and primary job as liquidity surface

### Rebuild
- Overview
- Books
- Receipts -> Finance Memory

### Likely unchanged or lightly adapted
- quotes
- invoices
- supporting finance navigation

## 6. Strategic differentiation
Finance Hub v2 is only truly differentiated if it becomes an engine, not just a redesign.

### Weak version
- new layout
- imported provider data
- Finn chat on the side

### Strong version
- one reconciled finance story
- provider-aware confidence model
- finance lens of Office Memory
- catch-up mode
- write-off / tax-review support
- owner-readable action queue
- memory-backed explanations

## 7. Success criteria
A low-financial-literacy owner should be able to enter Finance Hub and, within 30 seconds, understand:
- actual usable cash
- what changed recently
- what looks wrong or risky
- what may matter for tax review
- what to do next

## 8. Guardrails
- no CPA replacement claims
- no tax filing claims
- no guaranteed deduction claims
- no unsupported payroll/entity recommendations
- no multi-currency logic in v1
- no separate finance memory database

## 9. Required system stack
- Finance Story Engine
- provider mapping layer
- Office Memory finance projection
- Finn skill pack tool layer
- startup-mode orchestration
- action queue + authority gates

## 10. Final internal framing
### Product line
Finance Hub v2 is a reconciled money cockpit that turns Plaid, QuickBooks, Stripe, and Office Memory into one owner-readable financial story, one review queue, and one finance action system.

### Architecture line
Ava orchestrates the finance experience. Finn runs the finance specialization. Office Memory is the only memory spine. Finance Memory is its finance view.
