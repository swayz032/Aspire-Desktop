# Finance Story Engine Contract

## 1. Definition
Finance Story Engine is the canonical analysis layer that:
- collects provider data
- reads finance-scoped Office Memory
- reconciles differences
- scores confidence
- detects patterns and pressure
- emits one owner-readable money story plus next actions

It is the difference between:
- connected finance tools
and
- a finance operating system

## 2. Inputs
### 2.1 Provider inputs
- Plaid accounts, balances, transactions, recurring streams
- QuickBooks reports, accounts, customers, vendors, invoices, bills, payments
- Stripe quotes, invoices, invoice lifecycle events

### 2.2 Context inputs
- Finance Intake Profile
- provider connection state
- account mapping state
- finance-scoped Office Memory
- current mode: setup, catch-up, operating

## 3. Outputs
### 3.1 Story outputs
- `now`
- `next`
- `month`
- `reconcile`
- `actions`

### 3.2 Core UI outputs
- cash truth snapshot
- what changed summary
- pressure and risk list
- tax-review candidate summary
- top next actions
- provider coverage badge
- confidence score

## 4. Canonical output shape
```ts
type FinanceStoryOutput = {
  asOf: string;
  mode: 'setup' | 'catch-up' | 'operating';
  coverage: {
    plaid: boolean;
    quickbooks: boolean;
    stripe: boolean;
    unmappedAccountCount: number;
    mappingConfidence: 'low' | 'medium' | 'high';
    summaryBadge: string;
  };
  cashTruth: {
    usableCashUsd: number | null;
    committedCashUsd: number | null;
    unclearCashUsd: number | null;
    confidence: 'low' | 'medium' | 'high';
    notes: string[];
  };
  chapters: {
    now: StoryChapter;
    next: StoryChapter;
    month: StoryChapter;
    reconcile: StoryChapter;
    actions: StoryChapter;
  };
  taxReview: {
    candidateCount: number;
    estimatedReviewPoolUsd: number | null;
    missingEvidenceCount: number;
    mixedUseRiskCount: number;
  };
  signals: FinanceSignal[];
  actions: FinanceAction[];
};
```

## 5. Chapter intent
### now
What is true right now.

### next
What is about to matter next.

### month
What changed over the current review period.

### reconcile
What is incomplete, conflicting, or unmapped.

### actions
What the owner should do next.

## 6. Owner questions this engine must answer
1. What money is real right now?
2. Why do the numbers feel different from what I expected?
3. What looks wrong, risky, or incomplete?
4. What may matter for tax review?
5. What should I do next?

## 7. Confidence rules
### High
- key business accounts mapped
- provider coverage sufficient
- no major unmapped balance pools
- recent sync healthy

### Medium
- mostly mapped
- one or more notable unknowns remain
- story useful but partial

### Low
- missing critical provider
- major unmapped business account
- insufficient evidence to trust totals

## 8. Do not do this
- do not aggregate unmapped accounts into trusted cash
- do not present partial provider coverage as complete
- do not hide source disagreement
- do not present tax-review estimates as tax advice

## 9. Example story output
- Cash is stable, but lower than book profit suggests
- Two customer payments are still outstanding
- Fuel and materials rose over the last 14 days
- Eleven charges look review-worthy for tax prep, but four are missing evidence
- One business account is still not mapped to your books
- Best next move: confirm the unmapped account and review the highest-value expense candidates

## 10. Engine consumers
- Overview page
- Finn voice mode
- Finn video review mode
- Catch-Up Mode
- action queue
- finance memory event generation
