# Aspire Finance Hub v2 — Enterprise Handoff
Generated: 2026-03-14

## Purpose
This package is the enterprise-grade product, architecture, and implementation handoff for **Finance Hub v2** inside Aspire Desktop.

Finance Hub v2 is defined as:

> one reconciled money cockpit that turns Plaid, QuickBooks, Stripe, and Office Memory into one owner-readable financial story, one review queue, and one finance action system.

## Core decisions locked in
- **Office Memory is the only memory spine**
- **Finance Memory is the finance view of Office Memory**
- **Ava is the orchestrator**
- **Finn is the finance specialist skill pack**
- **USD only**
- **Cash page mostly stays**
- **Overview, Books, and Receipts are rebuilt**
- **Receipts becomes Finance Memory**
- **Plaid = bank reality**
- **QuickBooks = book truth**
- **Stripe = quote / invoice lifecycle truth**

## Package contents
1. `01_FINANCE_HUB_V2_MASTER_SPEC.md`
2. `02_FINANCE_STORY_ENGINE_CONTRACT.md`
3. `03_FINANCE_DATA_MODEL_AND_MAPPING.md`
4. `04_OFFICE_MEMORY_FINANCE_LENS_SPEC.md`
5. `05_FINN_SKILL_PACK_SPEC.md`
6. `06_FINANCE_HUB_STARTUP_MODES.md`
7. `07_OVERVIEW_PAGE_V2_SPEC.md`
8. `08_BOOKS_PAGE_V2_SPEC.md`
9. `09_FINANCE_MEMORY_PAGE_SPEC.md`
10. `10_CATCH_UP_MODE_SPEC.md`
11. `11_WRITE_OFF_RADAR_SPEC.md`
12. `12_FINANCE_PROFILE_FROM_ONBOARDING.md`
13. `13_API_AND_SERVICE_BOUNDARIES.md`
14. `14_IMPLEMENTATION_CHECKLIST.md`
15. `15_RISKS_OPEN_QUESTIONS_AND_DECISIONS.md`
16. `16_CURRENT_STATE_REPO_NOTES.md`
17. `17_TEST_PLAN_AND_ACCEPTANCE_CRITERIA.md`
18. `18_HANDOFF_MANIFEST.json`

## Recommended reading order
- Read `01` first
- Then `02`, `03`, `04`, `05`
- Then page specs `07`, `08`, `09`
- Then operational docs `10`, `11`, `12`, `13`
- Finish with `14`, `15`, `16`, `17`

## Handoff posture
This package is intended to be:
- product-complete
- architecture-aware
- implementation-oriented
- safe for Claude Code / senior engineer handoff
- explicit about non-goals and guardrails

## Non-goals
- No tax filing engine
- No CPA replacement
- No multi-currency support
- No fake certainty when provider coverage is partial
