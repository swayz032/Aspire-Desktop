# Write-Off Radar Spec

## 1. Purpose
Write-Off Radar is the tax-readiness review engine inside Finance Hub.

It helps owners find:
- likely business-expense candidates
- missing evidence
- mixed-use issues
- estimated review pools

It does not file taxes or replace a preparer.

## 2. Candidate lanes
- vehicle / fuel
- lodging
- meals
- travel
- materials
- subcontractors
- tools
- software
- utilities
- rent
- fees
- ambiguous mixed-use spend

## 3. Candidate object shape
```ts
type TaxReviewCandidate = {
  id: string;
  transactionId: string;
  merchant: string;
  postedAmountUsd: number;
  candidateType: string;
  confidence: number;
  whyFlagged: string[];
  businessUsePercent: number | null;
  categoryRulePercent: number | null;
  estimatedDeductionUsd: number | null;
  estimatedTaxSavingsUsd: number | null;
  evidenceStatus: 'present' | 'partial' | 'missing';
  mixedUseRisk: boolean;
  nextStep: string;
};
```

## 4. Review math
Use review estimates, not promises.

### Core formula
`deduction_candidate = posted_amount * business_use_percent * category_rule_percent`

### Tax impact estimate
`estimated_tax_savings = deduction_candidate * selected_estimated_tax_rate`

## 5. UI rule
Display:
- possible
- likely
- review needed
- estimated
- evidence missing

Do not display:
- guaranteed deduction
- guaranteed savings
- “this covers your tax bill”

## 6. Required output fields in UI
- merchant
- amount
- candidate type
- why flagged
- evidence status
- estimated review range
- estimated tax-impact range
- next step
- applicable rule reference label

## 7. Recommended reference presentation
Use plain labels such as:
- IRS travel/car/meal rules
- small business recordkeeping guidance
- business expense review guidance

Keep legal/tax wording minimal and practical.

## 8. Key safety boundary
Finance Hub can organize and estimate. It cannot pretend to conclude tax treatment with certainty.
