# Risks, Open Questions, and Decisions

## Locked decisions
- Office Memory is the only memory spine
- Finance Memory is the finance-scoped view
- Ava orchestrates
- Finn specializes
- USD only
- Plaid = bank reality
- QuickBooks = book truth
- Stripe = quote/invoice lifecycle truth
- Cash mostly stays
- Overview / Books / Receipts rebuilt

## Product risks
### 1. Redesign without engine
Risk:
- pretty shell
- same underlying fragmentation

Mitigation:
- build Finance Story Engine first

### 2. Overexposing accounting language
Risk:
- non-savvy owners bounce
- product feels like bookkeeping software

Mitigation:
- owner-safe default language
- accountant depth only on deliberate access

### 3. False trust from partial provider data
Risk:
- user sees incorrect totals
- product credibility collapses

Mitigation:
- explicit coverage and confidence model

### 4. Duplicate memory systems
Risk:
- Office Memory diverges from finance memory
- agent behavior becomes inconsistent

Mitigation:
- one memory spine only

### 5. Overclaiming tax capability
Risk:
- unsafe product language
- user trust damage

Mitigation:
- “review candidate” framing only
- evidence / confidence labels
- no guarantees

## Open technical questions
- what exact storage model will back finance memory events?
- how aggressively should similar transactions auto-batch for review?
- how much provider sync history should be retained raw vs summarized?
- what is the minimum acceptable mapping confidence for inclusion in cash truth?

## Open product questions
- how much of accountant mode should ship in v1?
- should reserve recommendations ship in v1 or v1.1?
- should catch-up mode create an export packet for third-party preparers in v1?

## Decision rule
When in doubt, choose:
- simpler owner flow
- more explicit confidence
- less silent automation
- more traceability
