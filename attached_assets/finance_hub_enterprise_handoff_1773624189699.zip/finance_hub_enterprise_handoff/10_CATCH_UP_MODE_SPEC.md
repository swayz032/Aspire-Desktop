# Catch-Up Mode Spec

## 1. Purpose
Catch-Up Mode is for owners with a messy year of money.

It exists to turn backlog into order.

## 2. Activation criteria
Use Catch-Up Mode when:
- there is significant historical data
- mapping/classification backlog is large
- the owner has not meaningfully organized the last 6–12 months
- tax-readiness confidence is low

## 3. Core jobs
- scan the last 12 months
- cluster activity into cleanup lanes
- prioritize highest-value review items
- build a tax-review-ready starting point
- reduce overwhelm

## 4. Cleanup lanes
### Lane A — Cash Truth
- inflows
- outflows
- pressure periods
- unexplained swings

### Lane B — Business Expense Review
- fuel
- lodging
- travel
- meals
- materials
- supplies
- tools
- subcontractors

### Lane C — Ambiguous Items
- transfers
- owner draws
- personal-looking spend
- duplicate-looking transactions

### Lane D — Invoice / Receivable History
- invoiced
- paid
- overdue
- recurring slow-paying customers

### Lane E — Tax-Readiness Gaps
- likely review-worthy expenses
- missing evidence
- weak classification coverage
- mixed-use risk

## 5. Output
Catch-Up Mode should produce:
- a year-in-review money story
- a prioritized cleanup order
- likely tax-review candidate groups
- the biggest money leaks
- first best next actions

## 6. UX rule
Do not make the owner review 12 months at once.

Break into sprints:
- Sprint 1: highest-value items
- Sprint 2: repeated merchants and transfer cleanup
- Sprint 3: tax-readiness pass

## 7. Finn’s role
Finn becomes the cleanup guide:
- explains the biggest lanes
- sets review order
- helps confirm ambiguous items
- writes progress back into Office Memory
