# Office Memory Finance Lens Spec

## 1. Core rule
Finance Memory is not a separate memory system.

> Finance Memory = the finance-scoped view of Office Memory.

## 2. Why this matters
If finance gets its own memory system, Aspire will create:
- duplicate truth
- divergent recommendations
- cross-agent inconsistency
- brittle retrieval

That is not acceptable.

## 3. What Office Memory should store for finance
- receipts
- evidence attachments
- provider event summaries
- invoice lifecycle events
- classification decisions
- mapping decisions
- anomaly explanations
- finance recommendations
- finance session summaries
- finance tasks
- approval outcomes
- reserve discussions
- tax-review decisions

## 4. Finance-scoped thread types
- vendor thread
- customer thread
- invoice thread
- tax-review thread
- mapping thread
- cash-pressure thread
- classification thread
- anomaly thread

## 5. Memory object types
```ts
type FinanceMemoryObjectType =
  | 'finance_fact'
  | 'finance_signal'
  | 'finance_recommendation'
  | 'finance_decision'
  | 'finance_evidence_gap'
  | 'finance_task'
  | 'finance_session_summary';
```

## 6. Example finance fact
```json
{
  "type": "finance_fact",
  "domain": "finance",
  "threadType": "vendor",
  "threadKey": "merchant:shell",
  "factKey": "merchant_cluster",
  "factValue": "fuel",
  "confidence": 0.84
}
```

## 7. What the agentic memory layer should do
Office Memory should not just store facts. It should:
- ingest finance events
- link related events
- detect recurring patterns
- surface unresolved finance items
- create follow-up prompts for the appropriate specialist
- preserve traceable decision history

## 8. What Finn should read from the finance lens
- repeated merchant behavior
- unresolved classification issues
- prior invoice/payment history
- prior explanations given to the owner
- recurring pressure patterns
- missing evidence chains
- prior approvals and rejections

## 9. What Finn should write back
- session summaries
- confirmed business-use facts
- confirmed merchant clusters
- resolved/unresolved task outcomes
- finance recommendations
- follow-up requests
- review packet generation events

## 10. Retrieval model
Finance retrieval should support:
- thread search
- entity search
- date-range search
- unresolved-only search
- confidence-filtered retrieval
- by-domain and by-object-type filtering

## 11. UI implication
The Finance Memory page should not feel like a receipt dump.

It should feel like:
- a history of financial decisions
- a map of unresolved money issues
- a record of what has been reviewed
- a chain of evidence and explanation
