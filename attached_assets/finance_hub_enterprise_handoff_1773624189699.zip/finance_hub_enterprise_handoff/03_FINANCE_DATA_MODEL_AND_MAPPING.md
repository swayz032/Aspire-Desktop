# Finance Data Model and Mapping

## 1. Why this layer exists
Finance Hub must not connect UI widgets directly to provider-specific shapes.

It needs:
- canonical entities
- explicit mapping state
- safe aggregation rules
- reusable story inputs

## 2. Canonical entities
### finance_account
Represents a business-relevant money container in canonical form.

### provider_account_link
Links a provider-specific account to a canonical finance account.

### counterparty
Represents a vendor, customer, merchant, or other recurring party.

### finance_transaction
Normalized transaction/event record across providers.

### invoice
Canonical invoice or receivable object.

### invoice_event
Lifecycle events for invoice, quote, payment, status changes.

### classification_decision
Structured record of how a transaction was categorized and why.

### mapping_decision
Structured record of how an account was linked, excluded, or left unresolved.

### tax_review_candidate
Structured review candidate for likely business expense or tax-relevant item.

### evidence_attachment
Receipt, note, document, or linked evidence.

### finance_signal
Detected issue, pattern, leak, anomaly, pressure, or recommendation.

### finance_task
Actionable queue item.

### finance_memory_event
Structured write-back into Office Memory.

## 3. Mapping model
### Mapping statuses
- `mapped`
- `suggested`
- `unmapped`
- `excluded`

### Mapping rules
Never silently assume:
- Plaid account == QuickBooks account
- a connected account is business-relevant
- provider totals are safe to merge

## 4. Account-mapping confidence
Confidence factors can include:
- account name similarity
- account subtype/type
- balance proximity
- owner confirmation
- recurring transaction behavior
- linked bookkeeping history

## 5. Canonical finance account shape
```ts
type FinanceAccount = {
  id: string;
  canonicalLabel: string;
  businessRole: 'operating_cash' | 'savings' | 'credit_card' | 'receivables' | 'payables' | 'other';
  status: 'active' | 'archived';
  includeInCashTruth: boolean;
};
```

## 6. Provider account link shape
```ts
type ProviderAccountLink = {
  id: string;
  financeAccountId: string | null;
  provider: 'plaid' | 'quickbooks' | 'stripe';
  providerAccountId: string;
  mappingStatus: 'mapped' | 'suggested' | 'unmapped' | 'excluded';
  confidence: number;
  sourceLabel: string;
  lastReviewedAt: string | null;
};
```

## 7. Counterparty normalization
The system should cluster:
- merchant names
- vendor entities
- customer names
- invoice clients

This improves:
- repeated classification
- pattern detection
- tax-review clustering
- finance memory threads

## 8. Safe aggregation rules
### Reconciled totals
Only include:
- mapped business accounts
- explicitly included accounts
- sufficiently trusted provider links

### Partial totals
If trust is incomplete:
- show unclear/unmapped pool separately
- downgrade confidence
- surface a review action

## 9. Event sourcing posture
Whenever possible, Finance Hub should preserve:
- raw provider references
- normalized objects
- derived finance signals
- write-back decisions

This avoids lossy summaries and makes finance memory traceable.

## 10. Required tables / collections
- finance_accounts
- provider_account_links
- finance_counterparties
- finance_transactions
- finance_invoices
- finance_invoice_events
- finance_classification_decisions
- finance_mapping_decisions
- finance_tax_review_candidates
- finance_evidence_attachments
- finance_signals
- finance_tasks
- finance_memory_events
