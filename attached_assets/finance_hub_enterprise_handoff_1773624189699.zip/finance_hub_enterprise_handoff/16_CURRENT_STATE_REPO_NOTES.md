# Current State Repo Notes

## Verified repo paths
- `app/(auth)/onboarding.tsx`
- `app/finance-hub/index.tsx`
- `app/finance-hub/books.tsx`
- `app/finance-hub/cash.tsx`
- `app/finance-hub/receipts.tsx`

## Observed current state
### Onboarding
Current onboarding already captures the key business profile fields Finance Hub should consume:
- business name
- owner name
- owner title
- industry
- industry specialty
- team size
- entity type
- years in business
- address
- timezone
- currency
- income range
- pain point
- consent fields

### Overview
Overview already appears to lean toward a normalized chapter-based story shape and contains Finn inside the main Finance Hub shell.

### Books
Books is currently too accounting-shaped with:
- Overview
- Reports
- Money Shelves
- Money Moves
- Money Trail

### Cash
Cash already exists as a separate surface and can remain the liquidity page.

### Receipts
Receipts is the page to replace with Finance Memory.

## Implication
The repo already has the shell and early conceptual direction.
What is missing is the canonical finance engine underneath it.
