# Finance Memory Page Spec

## 1. Purpose
Finance Memory replaces the old Receipts page.

It is the finance-scoped view of Office Memory:
- decisions
- evidence
- approvals
- patterns
- unresolved items
- explanation history

## 2. Why this replaces Receipts
A receipt list is not enough.

Owners need:
- what happened
- why it mattered
- what was decided
- what is still unresolved
- what evidence exists or is missing

## 3. Page sections
### A. Recent financial decisions
- classification approvals
- mapping confirmations
- reserve decisions
- invoice follow-up decisions

### B. Evidence and proof
- attached receipts
- supporting documents
- missing proof flags
- evidence quality score

### C. Financial history
- invoice/payment lifecycle
- payout and deposit history
- tax-review activity
- anomaly history

### D. Unresolved memory
- open finance tasks
- unresolved tax candidates
- unresolved mappings
- unresolved mixed-use items

### E. Thread views
Browse by:
- vendor
- customer
- invoice
- tax category
- account
- task status

## 4. Required object types shown on this page
- finance_fact
- finance_signal
- finance_decision
- finance_evidence_gap
- finance_task
- finance_session_summary

## 5. UX rule
This page should feel like:
- financial memory
- financial history
- decision traceability

Not like:
- a receipt dump
- a file cabinet
