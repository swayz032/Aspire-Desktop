# API and Service Boundaries

## 1. Service map
### Finance Story Engine service
Canonical finance analysis and story generation.

### Mapping service
Provider account and counterparty mapping logic.

### Finance projection service
Projects Office Memory into finance-scoped threads and views.

### Finn orchestration adapter
Routes finance context and tool calls to Finn.

### Provider connectors
- Plaid connector
- QuickBooks connector
- Stripe connector

## 2. Required read models
- Finance Intake Profile
- Provider Connection State
- Cash Truth Snapshot
- Books Snapshot
- Invoice Snapshot
- Finance Memory Projection
- Mapping Status Summary

## 3. Example endpoint/service contracts
### `GET /finance/profile`
Returns finance-safe onboarding-derived profile.

### `GET /finance/provider-state`
Returns provider connection and sync state.

### `GET /finance/story`
Returns Finance Story Engine output.

### `GET /finance/mapping-status`
Returns mapped/suggested/unmapped/excluded counts and details.

### `GET /finance/tax-review`
Returns tax review candidate summary and drill-down list.

### `GET /finance/memory`
Returns finance-scoped Office Memory projection.

### `POST /finance/tasks/{id}/resolve`
Resolves finance task.

### `POST /finance/mapping/confirm`
Applies mapping confirmation.

## 4. Write-back boundaries
Only structured finance events should be written back into Office Memory.

No freeform unstructured blob spam.

## 5. Authority boundaries
Actions that can materially affect finance state should stop at authority when necessary:
- classification batch apply
- mapping confirmation
- invoice follow-up send
- reserve-transfer draft creation

## 6. Ava/Finn boundary
Ava:
- selects mode
- decides routing
- enforces authority posture

Finn:
- runs finance-specific analysis and actions
- uses finance tools only
- writes finance-scoped memory events

## 7. Implementation note
Keep provider-specific logic behind adapters. Do not leak provider shape directly into page components.
