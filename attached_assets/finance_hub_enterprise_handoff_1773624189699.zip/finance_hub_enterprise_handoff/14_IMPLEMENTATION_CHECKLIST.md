# Implementation Checklist

## Phase 0 — lock decisions
- [ ] confirm USD-only
- [ ] confirm Office Memory is the only memory spine
- [ ] confirm Stripe role = quote/invoice lifecycle truth
- [ ] confirm Cash page shell mostly stays
- [ ] confirm Overview / Books / Receipts rebuild scope

## Phase 1 — contracts and models
- [ ] define Finance Intake Profile read model
- [ ] define canonical finance entities
- [ ] define mapping model and statuses
- [ ] define Finance Story Engine output contract
- [ ] define finance memory object schema

## Phase 2 — services
- [ ] build provider connection state service
- [ ] build mapping service
- [ ] build Finance Story Engine
- [ ] build finance memory projection service
- [ ] build tax-review candidate service

## Phase 3 — pages
- [ ] rebuild Overview page to consume story engine
- [ ] rebuild Books page as accounting workbench
- [ ] replace Receipts with Finance Memory page
- [ ] keep Cash page shell, improve data source layer

## Phase 4 — Finn integration
- [ ] implement Finn read tools
- [ ] implement Finn analysis tools
- [ ] implement Finn draft tools
- [ ] implement Finn write-back tools
- [ ] implement authority-gated tools

## Phase 5 — startup modes
- [ ] implement Setup Mode
- [ ] implement Catch-Up Mode
- [ ] implement Operating Mode
- [ ] wire Ava mode selection logic
- [ ] wire Finn session entry logic

## Phase 6 — catch-up and tax review
- [ ] implement 12-month scan
- [ ] cluster cleanup lanes
- [ ] build highest-value review prioritization
- [ ] implement Write-Off Radar candidate cards
- [ ] implement evidence-gap tracking

## Phase 7 — testing and polish
- [ ] test partial provider scenarios
- [ ] test unmapped account scenarios
- [ ] test no-accounting-literacy owner flows
- [ ] test voice/video Finn role separation
- [ ] test Office Memory write-backs
