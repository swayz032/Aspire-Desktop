# Overview Page v2 Spec

## 1. Purpose
Overview is the unified money briefing for the office.

It is not a dashboard of disconnected widgets.

## 2. Primary sections
### A. Cash Truth
Top strip with:
- usable operating cash
- committed / reserved amount
- unclear / unmapped amount
- confidence badge
- provider coverage badge

### B. What Changed
Recent movement:
- cash up/down
- major inflows/outflows
- paid/unpaid invoices
- repeated spend spikes
- new anomalies

### C. Pressure & Risk
Owner-facing risk layer:
- cash squeeze
- overdue invoices
- reserve pressure
- unmapped accounts
- duplicate suspicion
- classification backlog
- evidence gaps

### D. Potential Tax Review
- likely review-worthy expense categories
- estimated review pool
- missing evidence count
- mixed personal/business risk count

### E. Action Queue
- confirm mapping
- review tax candidates
- follow up overdue invoices
- approve classifications
- review reserve recommendations

## 3. Required badges
Examples:
- `Plaid + QBO + Stripe`
- `Plaid + QBO partial`
- `QBO only`
- `Plaid only`
- `1 unmapped account`
- `confidence: medium`

## 4. UI copy style
Prefer:
- “What you have”
- “What changed”
- “What needs attention”
- “Potential tax review”
- “Next moves”

Avoid leading with:
- “General ledger”
- “Trial balance”
- “Chart of accounts”

## 5. Finn in Overview
Finn should be embedded as:
- finance briefing
- “why” explainer
- next-action guide

Not as a detached side chatbot.

## 6. Success test
A low-financial-literacy owner should understand Overview within 3–5 seconds.
