# Test Plan and Acceptance Criteria

## 1. Acceptance criteria — owner comprehension
A low-financial-literacy owner can answer in under 30 seconds:
- what money is real
- what changed
- what needs review
- what to do next

## 2. Acceptance criteria — provider truth
### Scenario: Plaid only
- shows live cash and transaction story
- does not claim full book truth

### Scenario: QuickBooks only
- shows booked truth
- does not claim live bank truth

### Scenario: Stripe only
- shows quote/invoice lifecycle
- does not claim cash truth

### Scenario: Plaid + QuickBooks
- shows stronger story
- unresolved mappings clearly separated

### Scenario: Plaid + QuickBooks + Stripe
- shows strongest coverage badge
- invoice lifecycle included
- story remains one surface

## 3. Acceptance criteria — mapping
- unmapped accounts are visible
- unmapped balance pool is separated
- user can confirm mapping
- story confidence changes after mapping

## 4. Acceptance criteria — catch-up mode
Given 12 months of messy data:
- system does not dump raw rows first
- system builds cleanup lanes
- system prioritizes highest-value work
- Finn explains the plan in plain English

## 5. Acceptance criteria — finance memory
- decisions write back into Office Memory
- Finance Memory page reflects prior finance sessions
- unresolved items persist across sessions
- resolved items no longer dominate the queue

## 6. Acceptance criteria — Write-Off Radar
- flagged items show why they were flagged
- evidence status is visible
- estimates are labeled as estimates
- no guarantee language appears

## 7. Acceptance criteria — Finn
### Voice
- fast, short, action-focused
- no generic “how can I help” prompts

### Video
- structured, high-trust walkthrough
- evidence and reasoning visible

## 8. Non-functional expectations
- deterministic provider adapters
- explainable recommendations
- no silent merge of uncertain provider data
- traceable write-backs into Office Memory
