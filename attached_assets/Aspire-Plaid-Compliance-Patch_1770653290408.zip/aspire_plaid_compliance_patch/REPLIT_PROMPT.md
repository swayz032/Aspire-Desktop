You are implementing a compliance patch for the Aspire Expo Router web/desktop app to satisfy Plaid production questionnaire requirements.

Repository context:
- Project: Aspire-Desktop-lite (Expo Router)
- Domain: https://www.aspireos.app
- Plaid is already connected in Sandbox; do not break sandbox testing.

Goal:
Implement the files in this patch folder into the project, wire the screens into the existing More -> Policies hub, and gate Plaid Link connection behind user consent + MFA.

Hard rules:
1) Do NOT remove existing UI/UX styling.
2) Do NOT log Plaid access tokens.
3) Keep sandbox flow working: user must still be able to connect Plaid sandbox accounts after enabling MFA + granting consent.
4) Any “Yes” answer in Plaid questionnaire must correspond to an enforced control in code or infrastructure. If a control is not implemented, document it and recommend selecting “No”.

Tasks (do these in order):

A) Merge files
- Copy everything from this patch into the repo root, merging paths.
- Ensure these new routes build:
  - /more/privacy-policy
  - /more/terms
  - /more/data-retention
  - /more/plaid-consent

B) Install dependencies
- Add and install:
  - otplib
  - qrcode
  - expo-secure-store

C) Fix MFA imports
- The current code imports from `@/lib/security/mfa` but the file was missing in the repo. This patch adds it.
- Ensure `app/more/mfa-setup.tsx` and `app/more/mfa-verify.tsx` compile and work end-to-end.

D) Gate Plaid Link behind MFA + Consent
File to modify: `app/finance-hub/connections.tsx`
1) Before calling `createPlaidLinkToken()`, enforce:
   - MFA enabled (TOTP) AND verified in the last 12 hours
   - Plaid consent accepted (stored)
2) If missing:
   - Route to `/more/mfa-setup` or `/more/mfa-verify`
   - Route to `/more/plaid-consent`
3) Keep the existing card UI; just change the button behavior and add a small inline warning message.

E) Privacy policy URL
- Ensure the app exposes the policy at web path https://www.aspireos.app/more/privacy-policy (Expo web route)
- Also add a prominent “Open in browser” button that opens:
  - https://www.aspireos.app/privacy
  - https://www.aspireos.app/terms
  - https://www.aspireos.app/data-retention
  (these can be Next.js/static later; for now the Expo web routes are acceptable)

F) Produce receipts
Return:
1) List of files changed/added.
2) Screenshot(s) showing:
   - More -> Policies hub lists Privacy/Terms/Data Retention/Plaid Consent
   - Plaid Connect is blocked until consent + MFA
3) A short mapping from implemented controls to Plaid questionnaire answers (Q1–Q11).
