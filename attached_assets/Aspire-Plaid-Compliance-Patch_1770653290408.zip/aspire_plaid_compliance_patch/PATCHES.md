# Code changes to apply in Aspire-Desktop

This repo is Expo Router. These changes are intentionally small.

## 1) Add legal/compliance routes

Add these new screens under `app/more/`:
- `privacy-policy.tsx`
- `terms.tsx`
- `data-retention.tsx`
- `plaid-consent.tsx`

They are included in this patch.

## 2) Wire them into the More -> Policies page

File: `app/more/policies.tsx`

Update the policies list to include:
- Privacy Policy (route `/more/privacy-policy`)
- Terms of Service (route `/more/terms`)
- Data Retention & Deletion (route `/more/data-retention`)
- Plaid Consent (route `/more/plaid-consent`)

**Implementation note:** In the current codebase, `policies.tsx` is driven by `mockDb.getPolicies()`.
For fastest path, append these items in the mock DB policy list.

## 3) Require consent + MFA before initiating Plaid Link

File: `app/finance-hub/connections.tsx`

Change the `connectPlaid()` flow:
1. If user has not granted Plaid consent (`getPlaidConsent()` returns null or `consented:false`), route to `/more/plaid-consent`.
2. If MFA is not enabled (`getMfaStatus().enabled !== true`), route to `/more/mfa-setup`.
3. If MFA is enabled but not recently verified (`lastVerifiedAt` older than 12 hours), route to `/more/mfa-verify?returnTo=/finance-hub/connections`.
4. Only after (1)-(3) pass, call `plaidService.createLinkToken()` and open Plaid Link.

A reference implementation is in `docs/plaid/code_snippets.md`.

## 4) Add missing MFA + consent libs

Add the included files:
- `lib/security/storage.ts`
- `lib/security/mfa.ts`
- `lib/security/plaidConsent.ts`

## 5) Dependencies

Add these dependencies to `package.json`:
- `otplib`
- `qrcode`
- `expo-secure-store`

Then run:
- `npm install`

## 6) Public URLs (aspireos.app)

Because this is the Expo web app, publishing deploys these routes to:
- `https://www.aspireos.app/more/privacy-policy`
- `https://www.aspireos.app/more/terms`
- `https://www.aspireos.app/more/data-retention`
- `https://www.aspireos.app/more/plaid-consent`

If you prefer canonical URLs like `/privacy` and `/terms`, create shallow routes that redirect to the above.
