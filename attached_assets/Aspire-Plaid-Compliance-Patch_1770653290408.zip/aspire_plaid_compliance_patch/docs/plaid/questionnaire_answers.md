# Plaid Production Questionnaire – Aspire Answering Guide (Template)

This is a **truthful-by-construction** template: only choose the “Yes” options when the corresponding control is actually implemented and enforced.

## Q1 – Security contact
Provide a monitored group mailbox.
- Recommended entry:
  - **Tonio Scott — Founder & Security Lead**
  - **Email: security@aspireos.app**

## Q2 – Documented information security policy/program
**Pick based on reality:**
- If you have written policies + procedures and you actually operate them (access controls, incident response, vuln mgmt, logging, etc.) → select the first option.
- If you have some controls but documentation is incomplete → select the second option.
- If neither exists → select “No”.

**Implementation evidence to have on hand:**
- `/docs/security/infosec_policy.md` (create it)
- Change management notes
- Access control description

## Q3 – Access controls (select all that apply)
Common items Plaid expects in early-stage production:
- Role-based access control (RBAC) for production systems
- Centralized identity provider for staff (Google Workspace / Okta / AzureAD)
- Periodic access reviews (even quarterly)

If you are not operating these yet, do not select them.

## Q4 – MFA for consumers before Plaid Link is surfaced
If your app requires MFA (2FA) before the user can connect Plaid:
- Select **Yes — Non-phishing-resistant MFA** for TOTP / SMS / Email OTP.

This patch provides **TOTP** setup and a **Plaid consent** screen; you must also enforce gating in the connection flow.

## Q5 – MFA for access to critical systems storing/processing consumer financial data
This is about **your internal access** (production DB, cloud console, secret manager).
- If you have MFA on those admin systems → answer Yes (matching MFA type).
- If not → answer No.

## Q6 – TLS in transit
Should be **Yes** if you are serving the app and APIs over HTTPS and enforcing modern TLS.
- Evidence: TLS termination at a managed ingress (e.g., Cloudflare, Vercel, Render) + HSTS.

## Q7 – Encryption at rest for Plaid API data
If you store Plaid-derived data:
- Prefer “Yes — encrypt ALL at rest” if your DB uses disk encryption + application-level encryption for tokens/secrets.
- If you only encrypt sensitive fields, choose that.
- If you do not encrypt at rest, choose No.

Note: even if your DB storage is encrypted, **tokens** should be treated as secrets and stored in a secret store or encrypted column.

## Q8 – Vulnerability management
Pick items you actually do:
- Automated dependency scanning (Dependabot/GitHub Advanced Security)
- Patch within a defined SLA (e.g., critical within 7 days)
- Monitor EOL software

## Q9 – Privacy policy
You need:
- A public URL on your domain (recommended): `https://www.aspireos.app/privacy`
- In-app display (this patch adds an in-app page).

## Q10 – Consumer consent
You need explicit consent for collection/processing/storage.
- This patch includes `More -> Plaid consent` and stores a record locally.
- For production, store consent server-side with user + timestamp.

## Q11 – Data retention & deletion policy
You need a defined, enforced retention policy and a deletion process.
- Publish summary publicly (`/data-retention`) and provide an in-app version.
- Implement a user-facing “Delete account / Delete data” request flow (ticket/email or automated).
