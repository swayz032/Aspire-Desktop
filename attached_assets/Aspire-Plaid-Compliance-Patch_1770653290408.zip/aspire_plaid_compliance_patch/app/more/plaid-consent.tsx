import { useEffect, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { Stack, router } from 'expo-router';
import { Card } from '@/components/ui/card';
import { Text } from '@/components/ui/text';
import { Button } from '@/components/ui/button';
import { getPlaidConsent, setPlaidConsent } from '@/lib/security/plaidConsent';

/**
 * Plaid Consent (in-app)
 *
 * This is an explicit end-user consent screen for Plaid Link.
 * Store the user's acknowledgement so you can answer Plaid's consent questions truthfully.
 */
export default function PlaidConsent() {
  const [accepted, setAccepted] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const existing = await getPlaidConsent();
      setAccepted(existing);
      setLoading(false);
    })();
  }, []);

  const onAccept = async () => {
    await setPlaidConsent(true);
    setAccepted(true);
    router.back();
  };

  const onRevoke = async () => {
    await setPlaidConsent(false);
    setAccepted(false);
  };

  return (
    <>
      <Stack.Screen options={{ title: 'Plaid Consent' }} />
      <ScrollView className="flex-1 bg-background" contentContainerStyle={{ padding: 16 }}>
        <Card className="p-4">
          <Text className="text-lg font-semibold">Consent to connect your bank account</Text>
          <Text className="text-muted-foreground mt-2">
            Aspire uses Plaid Link to connect your financial institution and retrieve limited account data.
          </Text>

          <View className="mt-4">
            <Text className="font-semibold">What we access (read-only)</Text>
            <Text className="text-muted-foreground mt-1">
              • Account identifiers (institution + last 4)
              {'\n'}• Balances
              {'\n'}• Transactions (if you enable transaction feed)
            </Text>
          </View>

          <View className="mt-4">
            <Text className="font-semibold">What we do NOT do</Text>
            <Text className="text-muted-foreground mt-1">
              • We do not initiate bank transfers in the current MVP.
              {'\n'}• We do not store your bank login credentials.
            </Text>
          </View>

          <View className="mt-4">
            <Text className="font-semibold">Your controls</Text>
            <Text className="text-muted-foreground mt-1">
              You can disconnect Plaid at any time from Finance → Connections. You can request data deletion from More → Data Retention.
            </Text>
          </View>

          <View className="mt-4">
            <Text className="text-muted-foreground">
              By accepting, you authorize Aspire to access and process your Plaid data according to our Privacy Policy.
            </Text>
          </View>

          <View className="mt-6 flex-row gap-3">
            <Button disabled={loading || accepted} onPress={onAccept} className="flex-1">
              <Text>{accepted ? 'Already accepted' : 'Accept'}</Text>
            </Button>
            <Button variant="outline" disabled={loading || !accepted} onPress={onRevoke} className="flex-1">
              <Text>Revoke</Text>
            </Button>
          </View>
        </Card>
      </ScrollView>
    </>
  );
}
