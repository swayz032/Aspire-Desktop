import { ScrollView, View } from 'react-native';
import { Stack, router } from 'expo-router';
import { Card } from '@/components/ui/card';
import { Text } from '@/components/ui/text';
import { Button } from '@/components/ui/button';

/**
 * Policies hub.
 *
 * Goal: provide one place to find Privacy, Terms, Data Retention/Deletion,
 * and Plaid consent disclosure (required for Plaid diligence + end users).
 */
export default function Policies() {
  const open = (path: string) => router.push(path);

  return (
    <>
      <Stack.Screen options={{ title: 'Policies & Legal' }} />
      <ScrollView className="flex-1 bg-background">
        <View className="p-4 gap-4">
          <Card className="p-4">
            <Text className="text-lg font-semibold">Legal</Text>
            <Text className="text-sm text-muted-foreground mt-1">
              These pages are also intended to be published publicly on your domain.
            </Text>

            <View className="mt-4 gap-2">
              <Button variant="outline" onPress={() => open('/more/privacy-policy')}>
                <Text>Privacy Policy</Text>
              </Button>
              <Button variant="outline" onPress={() => open('/more/terms')}>
                <Text>Terms of Service</Text>
              </Button>
              <Button variant="outline" onPress={() => open('/more/data-retention')}>
                <Text>Data Retention & Deletion</Text>
              </Button>
            </View>
          </Card>

          <Card className="p-4">
            <Text className="text-lg font-semibold">Plaid</Text>
            <Text className="text-sm text-muted-foreground mt-1">
              Disclosure and consent required before Plaid Link is shown.
            </Text>

            <View className="mt-4 gap-2">
              <Button variant="outline" onPress={() => open('/more/plaid-consent')}>
                <Text>Plaid Consent</Text>
              </Button>
              <Button variant="outline" onPress={() => open('/more/security')}>
                <Text>Security Overview</Text>
              </Button>
              <Button variant="outline" onPress={() => open('/more/mfa-setup')}>
                <Text>Multi‑Factor Authentication (MFA)</Text>
              </Button>
            </View>
          </Card>
        </View>
      </ScrollView>
    </>
  );
}
