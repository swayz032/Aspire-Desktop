import { ScrollView, View } from 'react-native';
import { Stack } from 'expo-router';
import { Card } from '@/components/ui/card';
import { Text } from '@/components/ui/text';

/**
 * Privacy Policy (in-app)
 *
 * IMPORTANT:
 * - Keep this aligned with the public web policy at https://www.aspireos.app/privacy
 * - This file is meant to satisfy Plaid diligence + provide clear end-user disclosure.
 */
export default function PrivacyPolicy() {
  return (
    <>
      <Stack.Screen options={{ title: 'Privacy Policy' }} />
      <ScrollView className="flex-1 bg-background">
        <View className="p-4 gap-4">
          <Card className="p-4">
            <Text className="text-lg font-semibold">Aspire Privacy Policy</Text>
            <Text className="text-sm text-muted-foreground mt-1">
              Effective date: {new Date().getFullYear()}-02-08 (update this when you publish)
            </Text>
            <Text className="text-sm text-muted-foreground mt-2">
              Contact: security@aspireos.app
            </Text>
          </Card>

          <Card className="p-4 gap-2">
            <Text className="font-semibold">1. What Aspire is</Text>
            <Text className="text-sm text-muted-foreground">
              Aspire is a business operations and finance hub that lets users connect third-party services (for example,
              banking data through Plaid) to view balances, transactions, and related insights.
            </Text>
          </Card>

          <Card className="p-4 gap-2">
            <Text className="font-semibold">2. Data we collect</Text>
            <Text className="text-sm text-muted-foreground">
              We collect:
              {'\n'}• Account information you provide (e.g., name, email).
              {'\n'}• Application telemetry (basic diagnostics, device/app version, error logs).
              {'\n'}• If you choose to connect Plaid: limited financial data you authorize (for example balances and/or
              transactions).
            </Text>
          </Card>

          <Card className="p-4 gap-2">
            <Text className="font-semibold">3. How we use Plaid data</Text>
            <Text className="text-sm text-muted-foreground">
              Plaid data is used to:
              {'\n'}• Show account balances and transactions inside Aspire.
              {'\n'}• Power cash position and basic financial reporting features.
              {'\n'}• Improve reliability (e.g., reconcile sync status).
              {'\n'}We do not sell your banking data.
            </Text>
          </Card>

          <Card className="p-4 gap-2">
            <Text className="font-semibold">4. Consent and controls</Text>
            <Text className="text-sm text-muted-foreground">
              You control what you connect. You can disconnect Plaid at any time inside Aspire. When disconnected,
              Aspire will stop new data pulls and will follow the retention/deletion settings described below.
            </Text>
          </Card>

          <Card className="p-4 gap-2">
            <Text className="font-semibold">5. Data retention and deletion</Text>
            <Text className="text-sm text-muted-foreground">
              We minimize data and retain it only as long as necessary for providing the service and meeting legal/
              accounting obligations. You can request deletion by contacting security@aspireos.app. See the
              Data Retention page in More → Policies.
            </Text>
          </Card>

          <Card className="p-4 gap-2">
            <Text className="font-semibold">6. Security</Text>
            <Text className="text-sm text-muted-foreground">
              We use encryption in transit (TLS) and apply access controls to production systems. Sensitive secrets
              (API keys, access tokens) must be stored in server-side secret managers and must never be committed to
              source control.
            </Text>
          </Card>

          <Card className="p-4 gap-2">
            <Text className="font-semibold">7. Changes</Text>
            <Text className="text-sm text-muted-foreground">
              We may update this policy. Material changes will be communicated in-app and on our website.
            </Text>
          </Card>
        </View>
      </ScrollView>
    </>
  );
}
