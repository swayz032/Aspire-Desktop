import { ScrollView, View } from 'react-native';
import { Stack } from 'expo-router';
import { Card } from '@/components/ui/card';
import { Text } from '@/components/ui/text';

/**
 * Data Retention & Deletion (in-app)
 * Also publish equivalent content publicly at https://www.aspireos.app/data-retention
 */
export default function DataRetention() {
  return (
    <>
      <Stack.Screen options={{ title: 'Data Retention & Deletion' }} />

      <ScrollView className="flex-1 bg-background">
        <View className="p-4 gap-3">
          <Card className="p-4">
            <Text className="text-lg font-semibold">Retention approach</Text>
            <Text className="text-muted-foreground mt-2">
              Aspire retains only the data required to provide the requested features.
              Where possible, we store derived summaries and receipt metadata instead of raw data.
            </Text>
          </Card>

          <Card className="p-4">
            <Text className="text-lg font-semibold">Plaid data retention</Text>
            <Text className="mt-2">
              • Access tokens are stored server-side only.
            </Text>
            <Text className="mt-1">
              • Transaction and balance data is stored for a limited time needed for user-visible history and accounting sync.
            </Text>
            <Text className="mt-1">
              • You can disconnect Plaid to stop future pulls.
            </Text>
          </Card>

          <Card className="p-4">
            <Text className="text-lg font-semibold">Deletion</Text>
            <Text className="text-muted-foreground mt-2">
              You can request deletion of your account and associated data.
              For now, deletion requests are handled via support.
              Once the automated flow is implemented, this page will link to the self-serve deletion control.
            </Text>
            <Text className="mt-2">Email: privacy@aspireos.app</Text>
          </Card>

          <Card className="p-4">
            <Text className="text-lg font-semibold">Policy review cadence</Text>
            <Text className="text-muted-foreground mt-2">
              This policy is reviewed periodically and updated when product scope or regulatory requirements change.
            </Text>
          </Card>
        </View>
      </ScrollView>
    </>
  );
}
