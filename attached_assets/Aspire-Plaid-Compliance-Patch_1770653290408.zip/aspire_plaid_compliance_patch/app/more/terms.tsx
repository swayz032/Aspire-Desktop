import { ScrollView, View } from 'react-native';
import { Stack } from 'expo-router';
import { Card } from '@/components/ui/card';
import { Text } from '@/components/ui/text';

/**
 * Terms of Service (in-app)
 *
 * Also publish equivalent content publicly at:
 *   https://www.aspireos.app/terms
 */
export default function Terms() {
  return (
    <>
      <Stack.Screen options={{ title: 'Terms of Service' }} />

      <ScrollView className="flex-1 bg-background">
        <View className="p-4 gap-3">
          <Card className="p-4">
            <Text className="text-lg font-semibold">Summary</Text>
            <Text className="text-muted-foreground mt-2">
              Aspire is a business operations platform. You are responsible for
              authorizing connections to third-party services (e.g., Plaid,
              QuickBooks). Aspire is not a bank.
            </Text>
          </Card>

          <Card className="p-4">
            <Text className="text-lg font-semibold">Key Terms</Text>
            <Text className="mt-2">1. Account Security: You agree to use strong authentication (including MFA where available) and keep your credentials secure.</Text>
            <Text className="mt-2">2. Data Access: When you connect a provider, you authorize Aspire to access the specific data scopes you approve in that provider’s consent flow.</Text>
            <Text className="mt-2">3. Acceptable Use: No fraud, abuse, scraping, credential stuffing, or unlawful activity.</Text>
            <Text className="mt-2">4. Availability: Service is provided on an "as-is" basis; planned maintenance may occur.</Text>
            <Text className="mt-2">5. Termination: You can stop using Aspire at any time. Aspire may suspend access for security, fraud, or policy violations.</Text>
          </Card>

          <Card className="p-4">
            <Text className="text-lg font-semibold">Contact</Text>
            <Text className="text-muted-foreground mt-2">
              Support: support@aspireos.app{'
'}Security: security@aspireos.app
            </Text>
          </Card>

          <Text className="text-xs text-muted-foreground px-1">
            This in-app copy is a lightweight placeholder. Replace with attorney-reviewed terms before launch.
          </Text>
        </View>
      </ScrollView>
    </>
  );
}
