# Aspire Plaid Compliance Patch

This bundle contains **only the new/updated files** needed to help Aspire pass Plaid’s production security questionnaire (as far as an application can influence it):

## Included
- In-app legal pages:
  - `app/more/privacy-policy.tsx`
  - `app/more/terms.tsx`
  - `app/more/data-retention.tsx`
  - `app/more/plaid-consent.tsx`
  - Updated `app/more/policies.tsx` (hub to navigate the above)
- Security helpers:
  - `lib/security/storage.ts` (cross-platform storage wrapper)
  - `lib/security/plaidConsent.ts` (records end-user consent)
  - `lib/security/mfa.ts` (TOTP MFA helpers used by existing MFA screens)
- Docs:
  - `docs/plaid/questionnaire_answers.md` (how to answer truthfully based on implemented controls)
  - `PATCHES.md` (exact merge points)

## Required follow-up work (Replit)
1. **Install dependencies** (if not already present):
   - `otplib`
   - `qrcode`
   - `expo-secure-store`
2. **Publish public policy URLs** on `www.aspireos.app`:
   - `/privacy`
   - `/terms`
   - `/data-retention`
   These can be served by the Expo web build (same pages as in-app).
3. **Gate Plaid Link** behind:
   - MFA enabled + recently verified
   - Plaid consent recorded

## Output
Zip this folder and hand it to Replit. They will merge it into your repo and implement the small glue changes described in `PATCHES.md`.
