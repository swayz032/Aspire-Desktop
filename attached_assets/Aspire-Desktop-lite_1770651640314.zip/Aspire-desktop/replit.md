# Aspire Desktop Web App (Zenith Solutions)

## Overview
Aspire Desktop is an Expo/React Native for web business operations dashboard designed for founders. It integrates an AI assistant ("Ava"), cash flow monitoring, comprehensive task management, and advanced communication tools. The project aims to provide a unified platform for managing and optimizing business operations with a focus on AI-driven insights and automation, enhancing efficiency and strategic decision-making.

## User Preferences
I want iterative development.
Ask before making major changes.
I prefer detailed explanations.
The `public` folder contains static assets served directly (videos, images). Update as needed for media assets.

## System Architecture
Aspire Desktop is built with Expo SDK 54 and React Native for Web, using `expo-router` for file-based routing and TypeScript. The UI utilizes standard React Native components augmented by Expo libraries, with `@react-three/fiber` and `@react-three/drei` for 3D visualizations, and `react-native-reanimated` for animations.

A unified Express.js server runs on port 5000, serving static files and API routes for the booking system, Stripe payments, object storage, and Gusto payroll proxy. The application follows a modular structure with main app screens under `app/` and reusable components in `components/`, with state managed via Context Providers.

**Key Features & Technical Implementations:**
- **AI Assistants (Ava, Nora, Finn, Sarah, Eli, Clara, Quinn)**:
  - **Ava Desk**: Voice interaction via ElevenLabs Conversational AI using WebSockets and real-time video interaction via Anam AI. Features ChatGPT-style live activity chat.
  - **Finn Desk**: Finance AI assistant, a clone of Ava Desk with ElevenLabs voice and ChatGPT-style activity chat, focused on financial insights.
  - **Sarah (Front Desk)**: AI phone assistant with configurable lines, business hours, and routing.
  - **Office Store**: Marketplace for AI staff with glassmorphism cards and video demos.
- **Home Dashboard**: Provides an operational overview including cash position, tasks, and AI assistant access.
- **Inbox**: Enterprise-grade communication hub with Office, Calls, Mail, and Contacts tabs, featuring contextual filters and a single-panel layout.
- **Founder Hub**: Premium growth and learning platform with specialized subpages (Daily Brief, Pulse, Library, Studio, Notes, Templates, Masterminds, Saved).
- **Finance Hub**: Premium enterprise finance command center with a custom shell layout.
  - **Overview**: Fintech dashboard displaying cash trends, expense breakdowns, and KPI tiles.
  - **Cash**: Manages connected accounts, reserve allocations, and activity receipts.
  - **Books**: QuickBooks-inspired interface with Cash Flow Planner, Bank Transactions for Review, and financial Reports (P&L, Cash Flow, Balance Sheet).
  - **Payroll**: Full-featured payroll command center with 7 sub-tabs powered by live Gusto API data, including Run Payroll, People, Contractors, Time Off, Tax & Compliance, Pay History, and Settings.
  - **Connections**: Enterprise-grade provider connection hub supporting Plaid, QuickBooks Online, Gusto, and Stripe Connect with real OAuth/API flows.
  - **Invoices**: Full invoice management powered by Stripe SDK, with KPI cards, filter tabs, and creation/management actions.
- **Booking System**: Features an Express.js backend with PostgreSQL and Drizzle ORM, Stripe Checkout integration, an internal dashboard, and a client-facing booking page with a dark theme and glassmorphism design.
- **Team Workspace**: Enterprise delegation and governance hub with Suite Switcher, Seat Management, and five tabs (People, Approvals, Queues, Receipts, Usage) with role-based access.
- **Conference Lobby**: Premium pre-session staging room with an animated flip card for session preview and authority queue.

**UI/UX Decisions:**
- **Design Language**: Premium enterprise aesthetics, dark themes, glassmorphism, gradient accents, and subtle animations.
- **Color Scheme**: Consistent solid color palette (`#0a0a0a` background, `#1C1C1E` surfaces, `#3B82F6` accent blue) defined in `constants/tokens.ts`.
- **Audio Feedback**: Extensive use of Web Audio API for interactive sound effects.

## External Dependencies
- **ElevenLabs Conversational AI**: For "Ava Voice" and "Nora Voice" integrations.
- **Anam AI**: For "Ava Video" avatar integration.
- **Stripe Checkout**: For payment processing.
- **PostgreSQL**: Database.
- **Drizzle ORM**: ORM for PostgreSQL.
- **Expo SDK**: Core framework.
- **@react-three/fiber, @react-three/drei**: For 3D graphics.
- **react-native-reanimated**: For animations.
- **Recharts**: For real SVG-based charts in Finance Hub.
- **Gusto Embedded SDK**: For payroll integration.
- **Plaid SDK**: For bank account linking via Plaid Link.
- **QuickBooks OAuth**: Custom OAuth2 implementation for QuickBooks Online.
- **Stripe Connect**: OAuth flow for user Stripe account connections.

## Setup Guide (Fresh Project)

Follow these steps if you're starting this project fresh (e.g., from a ZIP download):

### 1. Install Dependencies
```bash
npm install
```

### 2. Set Up the Database
The app uses PostgreSQL. On Replit, a database is automatically provisioned. For local development, create a PostgreSQL database and set the `DATABASE_URL` environment variable.

The app automatically creates all required tables on first startup (via Drizzle ORM).

### 3. Configure Environment Variables
Copy `.env.example` to `.env` and fill in your provider API keys:
- **Plaid** (bank linking): Get sandbox keys at https://dashboard.plaid.com/developers/keys
- **Gusto** (payroll): Get sandbox keys at https://dev.gusto.com/
- **QuickBooks** (accounting): Get sandbox keys at https://developer.intuit.com/
- **Stripe** (payments): Get test keys at https://dashboard.stripe.com/test/apikeys

On Replit, add these as Secrets (lock icon in the sidebar) instead of using a `.env` file.

### 4. Build the Frontend
```bash
npx expo export --platform web
node scripts/fix-viewport.js
```
This generates the static web app in `dist/` with desktop viewport settings.

### 5. Start the Server
```bash
npx tsx server/index.ts
```
The server runs on port 5000 and serves both the web app and all API routes.

### 6. OAuth Tokens
OAuth tokens for Gusto, QuickBooks, and Plaid are automatically saved to the database after first login. They persist across server restarts — you do NOT need to set them manually.

## Build & Deploy Notes
- **Single server architecture**: Express on port 5000 serves pre-built Expo web app (from dist/) and all /api routes
- **Frontend changes require rebuild**: Run `npx expo export --platform web && node scripts/fix-viewport.js`
- **fix-viewport.js**: Patches dist/index.html with width=1280 viewport, min-width CSS, Plaid Link SDK, and copies public/ assets to dist/
- **Desktop-only mode**: useDesktop hook always returns true, dark theme (#0a0a0a background)

## Recent Changes (Feb 9, 2026)
- **Payroll Section Overhaul**: Removed hardcoded mock employees — page now starts empty, guiding users to add employees via People tab or connect payroll provider. Fixed Retrieve Payroll button spacing. Applied premium dark grey theme (#1C1C1E cards, glass borders) to all 6 payroll sub-pages (People, Contractors, Time Off, Tax & Compliance, Pay History, Settings). Added paystub PDF download button in modal (opens real Gusto API endpoint). Made Settings page interactive with Add Department/Location forms and inline editing.
- **Unified Banking Section**: Prominent cross-provider banking section on Connections page showing connected Plaid bank account with one-click Link buttons for Stripe (ACH Payments) and Gusto (Payroll Funding). Shows "Linked" status per service with green checkmarks.
- **Plaid Add Bank Button**: Added "Add Bank" button on Plaid card when already connected, allowing users to link additional bank accounts.
- **Plaid Cross-Provider Linking**: Backend endpoints for Plaid→Stripe (ACH bank token) and Plaid→Gusto (processor token) cross-linking. Security: processor tokens never returned to frontend.
- **Premium Dark Grey Card Redesign**: All Finance Hub pages (16+ files) redesigned from colorful gradient floods to solid dark grey (#1C1C1E) cards with thin glass borders (rgba(255,255,255,0.06)). Enterprise-grade SVG background patterns (chart lines, network nodes, currency symbols, people icons, invoice shapes, shield checks) imprinted into cards using `constants/cardPatterns.ts` module. GlassCard component rewritten. GlowBlob removed. No faded/washed-out appearance.
- **Authority Queue Integration**: Shared pub/sub store (`lib/authorityQueueStore.ts`) allows payroll proposals to appear on homepage Authority Queue. "Create Proposal" on Submit step adds a full payroll approval item with document preview, amount, employee count. Homepage merges dynamic items with static mock queue. Approval items route to Payroll page.
- **Gusto Paystub API**: Added `GET /api/gusto/employees/:uuid/pay-stubs` (JSON list) and `GET /api/gusto/payrolls/:payrollUuid/employees/:employeeUuid/pay-stub` (PDF). Both use token refresh with 401 retry.
- **Paystub Detail Modal**: "View" buttons on Receipts step open full paystub modal. Fetches real Gusto paystub data when connected (shows live data banner + pay history), falls back to calculated estimates in demo mode (amber demo banner). Earnings, taxes, deductions, net pay breakdown.
- **Run Payroll Wired to Gusto API**: Fetches real company/employees/payrolls/schedules, maps Gusto employees to display format, white-labeled (blue "P" logo), demo mode with amber banner when no employees exist.
- **Gusto White-Labeling Complete**: All user-facing "Gusto" references replaced with "Payroll" across 13 files (7 route pages + 6 components). Error messages now say "Payroll not configured" and direct users to Connections page.
- **Gusto API Coverage Expanded**: Added 20+ new endpoints covering employee CRUD, federal/state tax management, job/compensation tracking, payroll create/update/calculate/prepare/receipt, time-off requests & balances, contractor CRUD & payment groups, company updates, location & department creation.
- **Plaid Multi-Account Support**: Backend now supports multiple bank connections. Each Plaid item stored as separate `plaid:{item_id}` token. Legacy single-token format auto-migrated on startup. All routes (accounts, balances, transactions) aggregate across all connected banks. "Add Bank" button shown when already connected.
- **Project Import**: Imported fresh Aspire-Desktop app from user's zip archive with all latest code
- **3D Object Video**: Placed looping 3D object video (`ava-orb.mp4`) in public/ for use in Voice with Ava section and Finn Desk
- **A.I Staff Videos**: Placed all 5 AI staff intro videos (Clara, Eli, Nora, Quinn, Sarah) in public/staff-intros/ for the Office Store
- **Single Server Architecture**: Switched from two-server Metro+Express setup to single Express server on port 5000
- **Desktop Viewport**: fix-viewport.js patches dist/index.html with width=1280 viewport and copies public/ assets to dist/
- **Provider Keys Restored**: All sandbox API keys (Plaid, Gusto, QuickBooks, Stripe) re-added as Replit Secrets
- **OAuth Token Persistence**: Gusto and QuickBooks tokens stored in database via tokenStore.ts, loaded on startup
- **Gusto Embedded Rework**: Switched from standard OAuth "Connect Gusto" to proper Gusto Embedded payroll model with two paths:
  - **New users**: "Set Up Payroll" creates a partner-managed company via system-level token (no Gusto account needed)
  - **Existing users**: "Import Existing Account" uses OAuth + migration endpoint to bring existing Gusto company under Aspire management
  - System-level tokens: `grant_type: system_access` for partner operations
  - Company-level tokens: Per-company access/refresh tokens stored in database with expiry tracking
  - Proactive token refresh: Tokens refreshed automatically before 2-hour expiry
  - Connections page: Gusto card renamed to "Payroll" (white-labeled), dual-button UI with setup modal

## Gusto Embedded Architecture
- **White-labeled**: Users interact with "Payroll" in Aspire, not Gusto directly
- **Two authentication tiers**:
  - System token: Gets via client_id + client_secret, used for creating companies (no storage needed)
  - Company token: Returned when creating company, used for all payroll operations (stored in DB)
- **API endpoints**:
  - `POST /api/gusto/create-company` — Create partner-managed company for new users (uses system token internally)
  - `POST /api/gusto/migrate` — Migrate existing Gusto customer under embedded management
  - `GET /api/gusto/authorize` + `GET /api/gusto/callback` — OAuth flow for existing users
  - All existing proxy routes unchanged (employees, payrolls, contractors, etc.)
- **Demo environment**: `api.gusto-demo.com` (switch to `api.gusto.com` for production)

## Previous Changes (Feb 8, 2026)
- **Gusto OAuth Flow**: Added full OAuth authorization flow matching QuickBooks pattern
- **Cash Position Redesign**: Zero mock data, shows real Plaid accounts/balances when connected
- **Books Page Redesign**: 5 tabs wired to real QuickBooks API endpoints
- **Connections Page**: Updated Gusto connect button to use OAuth flow
- **Fixed Stripe client**: Rewrote server/stripeClient.ts to use STRIPE_SECRET_KEY env var directly