import React from 'react';
import { DesktopHome } from '@/components/desktop/DesktopHome';

export default function HomeScreen() {
  return <DesktopHome />;
}
